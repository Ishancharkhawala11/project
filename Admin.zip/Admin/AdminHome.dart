import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:uberclone/Admin/AdminReports.dart';
import 'package:uberclone/Admin/EmergencyHome.dart';

class Adminhome extends StatefulWidget {
  const Adminhome({super.key});

  @override
  State<Adminhome> createState() => _AdminhomeState();
}

class _AdminhomeState extends State<Adminhome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        // elevation: 5,
        leading: IconButton(
          icon: Icon(CupertinoIcons.back, color: Colors.yellowAccent),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        backgroundColor: Colors.black,
        title: Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Text(
            "Admin",
            style: TextStyle(fontFamily: "Bungee", fontSize: 50),
          ),
        ),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(MediaQuery.of(context).size.width * .7 / 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white,
                    spreadRadius: 5,
                    blurRadius: 20,
                  ),
                ],
              ),
              child: GestureDetector(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (_)=>Emergencyhome()));
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(MediaQuery.of(context).size.width * .7 / 2),
                  child: Container(
                    width: MediaQuery.of(context).size.width * .7,
                    height: MediaQuery.of(context).size.height * .2,
                    decoration: BoxDecoration(
                      color: Colors.yellow,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Center(
                        child: Text(
                          "Emergency",
                          style: TextStyle(color: Colors.black, fontSize: 25, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 40),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(MediaQuery.of(context).size.width * .7 / 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white,
                    spreadRadius: 5,
                    blurRadius: 20,
                  ),
                ],
              ),
              child: GestureDetector(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (_)=>AdminReport()));
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(MediaQuery.of(context).size.width * .7 / 2),
                  child: Container(
                    width: MediaQuery.of(context).size.width * .7,
                    height: MediaQuery.of(context).size.height * .2,
                    decoration: BoxDecoration(
                      color: Colors.yellow,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Center(
                        child: Text(
                          "Reports",
                          style: TextStyle(color: Colors.black, fontSize: 25, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
