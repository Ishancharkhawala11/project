import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Homedata extends StatefulWidget {
  const Homedata({super.key});

  @override
  State<Homedata> createState() => _HomedataState();
}

class _HomedataState extends State<Homedata> {
  late Future<List<Map<String, dynamic>>> _filteredReports;
  bool confirm = false;
  bool isUpdating = false;
  Future<String?> fetchAdminCity() async {
    final AdminSn =
        await FirebaseFirestore.instance.collection("AdminUser").get();
    if (AdminSn.docs.isNotEmpty) {
      return AdminSn.docs.first.data()["city"] as String?;
    }
    return null;
  }
Future<void> openMap({required String location})async
{
 if(location!=null && location.isNotEmpty)
   {
     final Uri uri=Uri.parse(location);
     if(await canLaunchUrl(uri))
       {
         await launchUrl(uri,mode: LaunchMode.externalApplication);
       }
     else {
       ScaffoldMessenger.of(context).showSnackBar(
         const SnackBar(content: Text("Location not available")),
       );
     }
   }
}
  Future<List<Map<String, dynamic>>> fetchReport() async {
    final admincity =await fetchAdminCity();
    if (admincity == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Unable to fetch Admin City")));
      return [];
    }
    final reportSnapshot = await FirebaseFirestore.instance
        .collection("Emergency")
        .where("city", isEqualTo: admincity)
        .where("service", isEqualTo: "Home")
        .get();
    final report = reportSnapshot.docs
        .map((doc) => {"id": doc.id, ...doc.data()} as Map<String, dynamic>)
        .toList();
    log(report.toString());
    return report;
  }
  Future<void> updatedata(String Id)async{
    setState(() {
      isUpdating=true;
    });
    try{
      await FirebaseFirestore.instance.collection("Emergency").doc(Id).update({
        "confirm":confirm,
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Service marked as done!")),
      );
    }catch(e){
      log("Error updating report: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: Could not update report.")),
      );
    }finally {
      setState(() {
        isUpdating = false;
        _filteredReports = fetchReport();
      });
    }
  }
  Future<void> _deleteReport(String reportId) async {
    try {
      await FirebaseFirestore.instance.collection("Emergency")
          .doc(reportId)
          .delete();
      setState(() {
        _filteredReports = fetchReport();
      });
    } catch (e) {
      log("Error deleting report: $e");
    }
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _filteredReports=fetchReport();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(CupertinoIcons.back, color: Colors.yellowAccent),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        backgroundColor: Colors.black,
        iconTheme: IconThemeData(
          color: Colors.yellowAccent,

        ),
        title: Text(
          "Home",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontFamily: "bungee",
            fontSize: 25,
          ),
        ),
      ),
      body: FutureBuilder<List<Map<String,dynamic>>>(
        future: _filteredReports,
        builder: (context,snapshot){
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text(
                "No data available",
                style: TextStyle(color: Colors.white, fontSize: 30),
              ),
            );
          }else{
            final homeData=snapshot.data!;
            return ListView.builder(itemBuilder: (context,index){
              final report = homeData[index];
              return Card(
                color: Colors.grey[850],
                margin: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 5),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: const BorderSide(color: Colors.white24, width: 1),
                ),
                child: ListTile(
                  title: Text("New Service For ${homeData[index]["service"]??"no title"}",style: TextStyle(color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),),
                  subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                  Text("Id num : ${homeData[index]["userid"]}",
                      style: TextStyle(
                          color: Colors.white, fontSize: 15)),
                  Text("State : ${homeData[index]["state"]}", style: TextStyle(
                      color: Colors.white, fontSize: 15)),
                  Text("City : ${homeData[index]["city"]}", style: TextStyle(
                      color: Colors.white, fontSize: 15)),
                  Text("Date : ${homeData[index]["Date"]}",
                      style: TextStyle(
                          color: Colors.white, fontSize: 15)),
                        homeData[index]["confirm"] == false
                            ? Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                onPressed: isUpdating
                                    ? null
                                    : () {
                                  setState(() {
                                    confirm = true;
                                  });
                                  updatedata(homeData[index]["id"]);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                ),
                                child: Text("Done"),
                              ),
                              SizedBox(width: MediaQuery
                                  .of(context)
                                  .size
                                  .width * 0.07),
                              ElevatedButton(
                                onPressed: () =>
                                    _deleteReport(report["id"]),
                                child: Text("Cancel"),
                              ),
                              SizedBox(width: MediaQuery
                                  .of(context)
                                  .size
                                  .width * 0.07),
                              ElevatedButton(
                                onPressed: ()async =>
                                {
await openMap(location: homeData[index]["location"])
                                },
                                child: Text("Location"),
                              ),
                            ],
                          ),
                        )
                            : SizedBox(width: 5),]
                  ),
                ),
              );
            },itemCount: homeData.length,);
          }
        },
      ),
    );
  }
}
