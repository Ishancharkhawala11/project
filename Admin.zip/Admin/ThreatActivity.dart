import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'Profs.dart';
class Threat extends StatefulWidget {
  const Threat({super.key});

  @override
  State<Threat> createState() => _ThreatState();
}

class _ThreatState extends State<Threat> {
  late Future<List<Map<String, dynamic>>> _filteredReports;
  bool confirm = false;
  bool _isUpdating = false;

  @override
  void initState() {
    super.initState();
    _filteredReports = fetchFilteredReports();
  }

  Future<String?> fetchAdminCity() async {

    final adminSnapshot = await FirebaseFirestore.instance.collection("AdminUser").get();
    if (adminSnapshot.docs.isNotEmpty) {

      return adminSnapshot.docs.first.data()["city"] as String?;
    }
    return null;
  }
  Future<void> updateData(String reportId) async {
    setState(() {
      _isUpdating = true;
    });

    try {
      await FirebaseFirestore.instance.collection("report").doc(reportId).update({
        "confirm": confirm,
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Report marked as done!")),
      );
    } catch (e) {
      log("Error updating report: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: Could not update report.")),
      );
    } finally {
      setState(() {
        _isUpdating = false;
        _filteredReports = fetchFilteredReports();
      });
    }
  }
  Future<List<Map<String, dynamic>>> fetchFilteredReports() async {
    final adminCity = await fetchAdminCity();
    if (adminCity == null) {
      log("Admin city not found.");
      return [];
    }


    final reportSnapshot = await FirebaseFirestore.instance.collection("report")
        .where("city", isEqualTo: adminCity).where("Activity",isEqualTo: "Threats")
        .get();
    final reports = reportSnapshot.docs
        .map((doc) => {
      "id": doc.id, ...doc.data(),
    } as Map<String, dynamic>)
        .toList();
    reports.sort((a, b) {
      final aConfirm = a["confirm"] as bool? ?? true;
      final bConfirm = b["confirm"] as bool? ?? true;
      return aConfirm == bConfirm ? 0 : (aConfirm ? 1 : -1);
    });

    return reports;
  }
  Future<void> _deleteReport(String reportId) async {
    try {
      await FirebaseFirestore.instance.collection("report").doc(reportId).delete();
      setState(() {
        _filteredReports = fetchFilteredReports();
      });
    } catch (e) {
      log("Error deleting report: $e");
    }
  }
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            centerTitle: true,
            backgroundColor: Colors.black,
            title: Text(
              "Threat",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontFamily: "bungee",
                fontSize: 25,
              ),
            ),
            iconTheme: IconThemeData(color: Colors.white),
          ),
          body: FutureBuilder<List<Map<String, dynamic>>>(
            future: _filteredReports,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text("Error: ${snapshot.error}"));
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(
                  child: Text(
                    "No data available",
                    style: TextStyle(color: Colors.white, fontSize: 30),
                  ),
                );
              } else {
                final reports = snapshot.data!;
                return ListView.builder(
                  itemCount: reports.length,
                  itemBuilder: (context, index) {
                    final report = reports[index];
                    return Card(
                      color: Colors.grey[850],
                      margin: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: const BorderSide(color: Colors.white24, width: 1),
                      ),
                      child: ListTile(
                        title: Text(
                          "New Report for ${report["Activity"] ?? "no title"}",
                          style: TextStyle(color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Id num : ${report["documentId"]}",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 15)),
                            Text("State : ${report["state"]}", style: TextStyle(
                                color: Colors.white, fontSize: 15)),
                            Text("City : ${report["city"]}", style: TextStyle(
                                color: Colors.white, fontSize: 15)),
                            Text("Date : ${report["dateTime"]}",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 15)),
                            report["confirm"] == false
                                ? Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ElevatedButton(
                                    onPressed: _isUpdating
                                        ? null
                                        : () {
                                      setState(() {
                                        confirm = true;
                                      });
                                      updateData(report["id"]);
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.green,
                                    ),
                                    child: Text("Done"),
                                  ),
                                  SizedBox(width: MediaQuery
                                      .of(context)
                                      .size
                                      .width * 0.08),
                                  ElevatedButton(
                                    onPressed: () =>
                                        _deleteReport(report["id"]),
                                    child: Text("Cancel"),
                                  ),
                                  SizedBox(width: MediaQuery
                                      .of(context)
                                      .size
                                      .width * 0.08),
                                  ElevatedButton(
                                    onPressed: () =>
                                    {
                                      Navigator.push(context, MaterialPageRoute(
                                          builder: (_) =>
                                              Profs(Userid: report["id"],)))
                                    },
                                    child: Text(" Profs "),
                                  ),
                                ],
                              ),
                            )
                                : SizedBox(width: 5),
                          ],
                        ),
                      ),
                    );
                  },
                );
              }
            },
          ),
        ),
        if (_isUpdating)
          Container(
            color: Colors.black54, // Semi-transparent background
            child: Center(
              child: CircularProgressIndicator(
                color: Colors.white,
              ),
            ),
          ),
      ],
    );
  }
}