import 'dart:developer';

import 'package:audioplayers/audioplayers.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

class Profs extends StatefulWidget {
  final String Userid;

  const Profs({super.key, required this.Userid});

  @override
  State<Profs> createState() => _ProfsState();
}

class _ProfsState extends State<Profs> {
  final AudioPlayer audio = AudioPlayer();
  VideoPlayerController? Video;
  String? audiourl;
  String? imageUrl;
  String? des;
  String? location;
  String? videoUrl;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  @override
  void dispose() {
    audio.dispose();
    super.dispose();
  }

  Future<void> fetchData() async {
    final sn = await FirebaseFirestore.instance
        .collection("report")
        .doc(widget.Userid)
        .get();
    if (sn.exists) {
      setState(() {
        audiourl = sn.get("audio");
        imageUrl = sn.get("image");
        des = sn.get("description");
        location=sn.get("location").toString();
        videoUrl=sn.get("video");
      });
    }
  }
  Future<void> playVideo() async {
    try {
      if (videoUrl != null && videoUrl!.isNotEmpty) {
        Video = VideoPlayerController.network(videoUrl!);


        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return Center(
              child: CircularProgressIndicator(
                color: Colors.yellowAccent,
              ),
            );
          },
        );

        await Video!.initialize();


        Navigator.pop(context);

        setState(() {});
        Video!.play();


        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Scaffold(
              backgroundColor: Colors.black,
              appBar: AppBar(
                backgroundColor: Colors.black,
                title: const Text("Video Player", style: TextStyle(color: Colors.white)),
                iconTheme: const IconThemeData(color: Colors.white),
              ),
              body: Center(
                child: AspectRatio(
                  aspectRatio: Video!.value.aspectRatio,
                  child: VideoPlayer(Video!),
                ),
              ),
            ),
          ),
        );

        Video!.pause();
      } else {
        throw Exception("No video available");
      }
    } on PlatformException catch (e) {

      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No video available")),
      );
    } catch (e) {

      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No video available")),
      );
    }
  }

  Future<void> openMap() async {
    try {
      if (location != null && location!.isNotEmpty) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return Center(
              child: CircularProgressIndicator(
                color: Colors.yellowAccent,
              ),
            );
          },
        );
        final Uri uri = Uri.parse(location!);
        if (await canLaunchUrl(uri)) {


          await launchUrl(uri, mode: LaunchMode.externalApplication);
          Navigator.pop(context);
        }

      }
    } on PlatformException catch (e) {

      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Could not open the map with ")),
      );
    }catch(e){
    ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text("Location not available")));
    }
  }

  Future<void> playAudio() async {
    if (audiourl != null && audiourl!.isNotEmpty) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Center(
            child: CircularProgressIndicator(
              color: Colors.yellowAccent,
            ),
          );
        },
      );
      try {
        await audio.play(UrlSource(audiourl!));
        Navigator.pop(context);
      } catch (e) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Error playing audio")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No audio available")),
      );
    }
  }


  void showImageGallery() {
    if (imageUrl != null && imageUrl!.isNotEmpty) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Center(
            child: CircularProgressIndicator(
              color: Colors.yellowAccent,
            ),
          );
        },
      );
      try {
        Navigator.pop(context);  // Close the loading dialog before opening the image gallery

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => Scaffold(
              backgroundColor: Colors.black,
              appBar: AppBar(
                backgroundColor: Colors.black,
                title: const Text(
                  "Image Gallery",
                  style: TextStyle(color: Colors.white),
                ),
                iconTheme: IconThemeData(color: Colors.white),
              ),
              body: PhotoViewGallery(
                pageOptions: [
                  PhotoViewGalleryPageOptions(
                    imageProvider: NetworkImage(imageUrl!),
                    minScale: PhotoViewComputedScale.contained,
                    maxScale: PhotoViewComputedScale.covered * 2,
                  ),
                ],
                scrollPhysics: const BouncingScrollPhysics(),
                backgroundDecoration: BoxDecoration(color: Colors.black),
              ),
            ),
          ),
        );
      } on PlatformException catch (e) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Could not open the image")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No image available")),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        centerTitle: true,
        title: const Text(
          "Profs",
          style: TextStyle(
              fontWeight: FontWeight.bold, fontFamily: "bungee", fontSize: 30),
        ),
      ),
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(top: MediaQuery.of(context).size.height * .1),
          child: Column(
            children: [
              Container(
                width: MediaQuery.of(context).size.width * .9,
                decoration: BoxDecoration(
                  color: Colors.yellowAccent,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(top: 20),
                      child: Text(
                        "Description",
                        style: TextStyle(
                            fontSize: 25,
                            color: Colors.black,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Center(
                        child: Text(
                          textAlign: TextAlign.justify,
                          des?.isNotEmpty == true ? des! : "No description available",
                          style: const TextStyle(
                              fontSize: 15,
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const Center(
                child: Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: Text(
                    "Show all profs Here",
                    style: TextStyle(
                        fontSize: 20,
                        color: Colors.yellowAccent,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: openMap,
                      child: _buildCard("Location")),
                  SizedBox(width: MediaQuery.of(context).size.width * .03),
                  GestureDetector(
                    onTap: showImageGallery,
                    child: _buildCard("Image"),
                  ),
                ],
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(onTap: (){
                    if(videoUrl.toString()==null)
                      {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("No video Availble")));
                      }
                    else{
                      playVideo();
                    }
                  },child: _buildCard("Video")),
                  SizedBox(width: MediaQuery.of(context).size.width * .03),
                  GestureDetector(
                    onTap: playAudio,
                    child: _buildCard("Audio"),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard(String title) {
    return Container(
      width: MediaQuery.of(context).size.width * .4,
      height: MediaQuery.of(context).size.height * .2,
      decoration: BoxDecoration(
        color: Colors.yellowAccent,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Center(
        child: Text(
          title,
          style: const TextStyle(
              fontSize: 20, color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
