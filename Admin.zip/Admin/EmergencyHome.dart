import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:uberclone/Admin/ChildHelp.dart';
import 'package:uberclone/Admin/EMergencyData.dart';
import 'package:uberclone/Admin/FireData.dart';
import 'package:uberclone/Admin/HomeData.dart';
import 'package:uberclone/Admin/PoliceData.dart';
import 'package:uberclone/Admin/WildLife.dart';
import 'package:uberclone/Admin/WomenHelp.dart';

class Emergencyhome extends StatefulWidget {
  const Emergencyhome({super.key});

  @override
  State<Emergencyhome> createState() => _EmergencyhomeState();
}

class _EmergencyhomeState extends State<Emergencyhome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          padding: EdgeInsets.only(top: MediaQuery.of(context).size.height * 0.05),
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Icon(
                        CupertinoIcons.back,
                        color: Colors.yellowAccent,
                        size: 28,
                      ),
                    ),
                    Expanded(
                      child: Center(
                        child: Text(
                          "Emergency Services",
                          style: TextStyle(
                            fontSize: 24,
                            fontFamily: "bungee",
                            color: Colors.yellowAccent,
                          ),
                        ),
                      ),
                    ),
]
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height*.05,),
            GestureDetector(
                onTap: ()=>Navigator.push(context,MaterialPageRoute(builder: (_)=>Homedata())),
                child: _Container("Home", context)),
              SizedBox(height: MediaQuery.of(context).size.height*.02,),
              GestureDetector(
                onTap: ()=>Navigator.push(context,MaterialPageRoute(builder: (_)=>Emergencydata())),
                  child: _Container("Ambulance", context)),
              SizedBox(height: MediaQuery.of(context).size.height*.02,),
              GestureDetector(
                  onTap: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Firedata() )),
                  child: _Container("Fire", context)),
              SizedBox(height: MediaQuery.of(context).size.height*.02,),
              GestureDetector(
                  onTap: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Policedata())),
                  child: _Container("Police", context)),
              SizedBox(height: MediaQuery.of(context).size.height*.02,),
              GestureDetector(
                  onTap: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Womendata())),
                  child: _Container("Women Help", context)),
              SizedBox(height: MediaQuery.of(context).size.height*.02,),
              GestureDetector(
                  onTap: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Childhelp())),
                  child: _Container("Child Help", context)),
              SizedBox(height: MediaQuery.of(context).size.height*.02,),
              GestureDetector(
                  onTap: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>WildLife())),
                  child: _Container("WildLife Supporter", context)),
            ],
          ),
        ),
      ),
    );
  }
}
Widget _Container(String Title,BuildContext context)
{
  return  Container(
    width: MediaQuery.of(context).size.width*.8,
    height: MediaQuery.of(context).size.height*.1,
    decoration: BoxDecoration(
      color: Colors.yellowAccent,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: Colors.yellow,style: BorderStyle.solid,width: 5),

    ),
    child: Center(child: Text(Title,style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),)),
  );
}