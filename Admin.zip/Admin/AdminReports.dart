import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:uberclone/Admin/Abusing.dart';
import 'package:uberclone/Admin/Criminal%20Activity.dart';
import 'package:uberclone/Admin/Sucide.dart';
import 'package:uberclone/Admin/ThreatActivity.dart';

class AdminReport extends StatefulWidget {
  const AdminReport({super.key});

  @override
  State<AdminReport> createState() => _AdminReportState();
}

class _AdminReportState extends State<AdminReport> {
  int currentIndex = 0;
  late List<Widget> pages;

  late CriminalActivity CA;
  late Abusing AB;
  late Threat TH;
  late Sucide SU;
  bool tap=false;

  @override
  void initState() {
    super.initState();
    CA = const CriminalActivity();
    AB = const Abusing();
    TH = const Threat();
    SU = const Sucide();
    pages = [CA, AB, TH, SU];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: CurvedNavigationBar(
        height: 50,
        backgroundColor: Colors.black,
        color: Colors.yellowAccent,
        animationDuration: const Duration(milliseconds: 500),
        onTap: (int index) {
          setState(() {
            currentIndex = index;
          });
        },
        buttonBackgroundColor: Colors.yellowAccent,
        maxWidth: MediaQuery.of(context).size.width,

        items: const [
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.gavel,color: Colors.black, size: 20),
              Text("Criminal", style: TextStyle(fontSize: 10,color: Colors.black))
            ],
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.warning,color: Colors.black, size: 20),
              Text("Abusing", style: TextStyle(fontSize: 10,color: Colors.black))
            ],
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.security,color: Colors.black, size: 20),
              Text("Threat", style: TextStyle(fontSize: 10,color: Colors.black))
            ],
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.sentiment_dissatisfied,color: Colors.black, size: 20),
              Text("Suicide", style: TextStyle(fontSize: 10,color: Colors.black))
            ],
          ),
        ],
      ),
      body: pages.isNotEmpty ? pages[currentIndex] : Center(child: Text("Page not found")),
    );
  }
}
