import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:uberclone/Admin/AdminHome.dart';
import 'package:uberclone/Local/SharedPreference.dart';
import '../Widgets/CustomWidgets.dart';
import 'package:device_info_plus/device_info_plus.dart';

class AdminLog extends StatefulWidget {
  const AdminLog({super.key});

  @override
  State<AdminLog> createState() => _AdminLogState();
}

class _AdminLogState extends State<AdminLog> {
  final _formKey = GlobalKey<FormState>();
  String? email;
  String? password;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;
  String? selectedState = "Andhra Pradesh";
  String? selectedCity;
  String? deviceId;
  final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
  String? position;
  String? place;
  User? user=FirebaseAuth.instance.currentUser;

  Map<String, List<String>> stateCities = {
    "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Tirupati", "Kakinada", "Kurnool", "Rajahmundry", "Kadapa", "Anantapur", "Srikakulam", "Eluru", "Chittoor", "Vizianagaram"],
    "Arunachal Pradesh": ["Itanagar", "Pasighat", "Tawang", "Ziro", "Tezu", "Bomdila", "Aalo", "Roing", "Changlang"],
    "Assam": ["Guwahati", "Silchar", "Dibrugarh", "Jorhat", "Nagaon", "Tinsukia", "Tezpur", "Bongaigaon", "Barpeta", "Karimganj"],
    "Bihar": ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Purnia", "Darbhanga", "Arrah", "Begusarai", "Katihar", "Sasaram", "Hajipur", "Siwan"],
    "Chhattisgarh": ["Raipur", "Bilaspur", "Durg", "Bhilai", "Korba", "Rajnandgaon", "Raigarh", "Jagdalpur", "Ambikapur", "Mahasamund"],
    "Goa": ["Panaji", "Margao", "Vasco da Gama", "Mapusa", "Ponda", "Bicholim", "Sanquelim", "Curchorem", "Valpoi"],
    "Gujarat": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Gandhinagar", "Junagadh", "Nadiad", "Morbi", "Anand", "Navsari", "Bharuch"],
    "Haryana": ["Chandigarh", "Faridabad", "Gurgaon", "Panipat", "Ambala", "Yamunanagar", "Hisar", "Rohtak", "Karnal", "Sonipat", "Sirsa", "Panchkula", "Bhiwani"],
    "Himachal Pradesh": ["Shimla", "Dharamshala", "Solan", "Mandi", "Kullu", "Bilaspur", "Chamba", "Hamirpur", "Una", "Nahan", "Palampur"],
    "Jharkhand": ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro", "Deoghar", "Hazaribagh", "Giridih", "Ramgarh", "Phusro", "Chirkunda"],
    "Karnataka": ["Bengaluru", "Mysuru", "Mangaluru", "Hubballi-Dharwad", "Belagavi", "Kalaburagi", "Ballari", "Davangere", "Tumakuru", "Shivamogga", "Udupi", "Vijayapura"],
    "Kerala": ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam", "Kannur", "Alappuzha", "Palakkad", "Malappuram", "Kottayam", "Pathanamthitta"],
    "Madhya Pradesh": ["Bhopal", "Indore", "Gwalior", "Jabalpur", "Ujjain", "Sagar", "Dewas", "Satna", "Ratlam", "Rewa", "Shivpuri", "Chhindwara", "Katni"],
    "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Nashik", "Aurangabad", "Solapur", "Amravati", "Kolhapur", "Nanded", "Sangli", "Jalgaon", "Akola", "Latur", "Dhule"],
    "Manipur": ["Imphal", "Thoubal", "Bishnupur", "Churachandpur", "Senapati", "Ukhrul", "Tamenglong", "Jiribam"],
    "Meghalaya": ["Shillong", "Tura", "Nongpoh", "Jowai", "Baghmara", "Williamnagar", "Resubelpara"],
    "Mizoram": ["Aizawl", "Lunglei", "Saiha", "Champhai", "Serchhip", "Lawngtlai", "Kolasib"],
    "Nagaland": ["Kohima", "Dimapur", "Mokokchung", "Tuensang", "Wokha", "Mon", "Phek", "Zunheboto"],
    "Odisha": ["Bhubaneswar", "Cuttack", "Rourkela", "Berhampur", "Sambalpur", "Puri", "Balasore", "Baripada", "Bhadrak", "Jeypore", "Jharsuguda"],
    "Punjab": ["Chandigarh", "Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Mohali", "Hoshiarpur", "Moga", "Pathankot", "Phagwara"],
    "Rajasthan": ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Ajmer", "Bikaner", "Alwar", "Bharatpur", "Sikar", "Pali", "Nagaur", "Tonk"],
    "Sikkim": ["Gangtok", "Namchi", "Gyalshing", "Mangan", "Rangpo", "Singtam"],
    "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Erode", "Vellore", "Thoothukudi", "Dindigul", "Thanjavur", "Nagercoil"],
    "Telangana": ["Hyderabad", "Warangal", "Nizamabad", "Khammam", "Karimnagar", "Ramagundam", "Mahbubnagar", "Nalgonda", "Adilabad"],
    "Tripura": ["Agartala", "Udaipur", "Dharmanagar", "Kailashahar", "Belonia", "Khowai"],
    "Uttar Pradesh": ["Lucknow", "Kanpur", "Ghaziabad", "Agra", "Meerut", "Varanasi", "Prayagraj", "Bareilly", "Aligarh", "Moradabad", "Saharanpur", "Firozabad", "Jhansi"],
    "Uttarakhand": ["Dehradun", "Haridwar", "Roorkee", "Haldwani", "Rudrapur", "Kashipur", "Nainital", "Almora", "Pithoragarh"],
    "West Bengal": ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri", "Bardhaman", "Kharagpur", "Malda", "Jalpaiguri", "Haldia", "Bankura"],
  };




  Future<void> getcred() async {
    String? email = await SharedpreferenceClass.getUserEmail();
    setState(() {
      this.email = email;
    });
  }

  Future<bool> _checkLocationPermision() async {
    if (await Permission.location.isGranted) {
      return true;
    } else {
      var status = await Permission.location.request();
      return status.isGranted;
    }
  }

  Future<String> getaddress(double lat, double long) async {
    try {
      List<Placemark> placemark = await placemarkFromCoordinates(lat, long);
      if (placemark.isNotEmpty) {
        Placemark place = placemark[0];
        setState(() {
          this.place = place.locality;
        });

        return "${place.subLocality},${place.locality},${place.administrativeArea}";
      }
      return "No address found";
    } catch (e) {
      return "Failed to get address: $e";
    }
  }

  Future<Position> _getCurrentLocation() async {
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  void _fetchLocation() async {
    bool permission = await _checkLocationPermision();
    if (permission) {
      try {
        Position possition = await _getCurrentLocation();
        log(possition.toString());
        String add = await getaddress(possition.latitude, possition.longitude);
        setState(() {
          this.position = add;
        });

      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error getting location: $e")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Location permission not granted")),
      );
    }
  }

  Future<void> getuserInfo() async {
    try {
      DocumentSnapshot adminCred = await FirebaseFirestore.instance.collection('Admin').doc(email).get();

      if (adminCred.exists) {
        if (email.toString() == adminCred['username']) {
          if (password.toString() == adminCred['password']) {
            setState(() {
              _isLoading = true;
            });
            if(this.place.toString().toLowerCase()==selectedCity.toString().toLowerCase()) {
                await addAdminUser();
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=>Adminhome()));
              }else
              {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("Enter valid location"),
                    backgroundColor: Colors.red,
                  ),
                );
              }
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Incorrect password or no city selected')),
            );
          }
          setState(() {
            _isLoading = false;
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Incorrect username')),
          );
        }
        setState(() {
          _isLoading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No such user exists')),
        );
      }
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('An error occurred: $e')),
      );
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> addAdminUser() async {
    await _getDeviceId();
    await FirebaseFirestore.instance.collection("AdminUser").add({
      "email": email.toString(),
      "state": selectedState.toString(),
      "city": selectedCity.toString(),
      "location": position.toString(),
      "deviceId": deviceId,
      "timestamp": FieldValue.serverTimestamp(),
    });
  }

  Future<void> _getDeviceId() async {
    if (Theme.of(context).platform == TargetPlatform.android) {
      AndroidDeviceInfo androidInfo = await deviceInfoPlugin.androidInfo;
      setState(() {
        deviceId = androidInfo.id;
      });
      log(deviceId.toString());
    } else if (Theme.of(context).platform == TargetPlatform.iOS) {
      IosDeviceInfo iosInfo = await deviceInfoPlugin.iosInfo;
      setState(() {
        deviceId = iosInfo.identifierForVendor;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    getcred();
    _fetchLocation();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.2),
                  Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: const [
                        Text(
                          "Admin!",
                          style: TextStyle(
                            color: Colors.yellowAccent,
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                            fontFamily: "Bungee",
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: MediaQuery.of(context).size.height * 0.05),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            const SizedBox(height: 20),
                            CustomTextFormField.customTextFormField(
                              hintText: "Password",
                              prefixIcon: Icons.lock_outline,
                              obscureText: true,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your password';
                                }
                                return null;
                              },
                              onSaved: (value) => password = value,
                            ),
                            const SizedBox(height: 40),
                            FormField<String>(
                              builder: (FormFieldState<String> state) {
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _buildRow(
                                      context,
                                      label: "Select State",

                                      child: DropdownButtonFormField<String>(
                                        menuMaxHeight: 300,
                                        value: selectedState,
                                        items: stateCities.keys.map((state) {
                                          return DropdownMenuItem<String>(
                                            value: state,
                                            child: Text(
                                              state,
                                              style: CustomTextFormField.CustomText(fontSize: 20,color: Colors.white),
                                            ),
                                          );
                                        }).toList(),
                                        onChanged: (value) {
                                          setState(() {
                                            selectedState = value!;
                                            selectedCity = null;
                                          });
                                        },
                                        decoration: const InputDecoration(
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(color: Colors.yellowAccent),
                                          ),
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(color: Colors.yellowAccent),
                                          ),
                                        ),
                                        dropdownColor: Colors.black,
                                        style: const TextStyle(color: Colors.white),
                                        iconEnabledColor: Colors.yellowAccent,
                                        alignment: AlignmentDirectional.bottomStart,
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                            const SizedBox(height: 20),
                            FormField<String>(
                              builder: (FormFieldState<String> state) {
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _buildRow(
                                      context,
                                      label: "Select City",
                                      child: DropdownButtonFormField<String>(
                                        menuMaxHeight: 300,

                                        value: selectedCity,
                                        items: (stateCities[selectedState] ?? []).map((city) {
                                          return DropdownMenuItem<String>(
                                            value: city,
                                            child: Text(
                                              city,
                                              style: CustomTextFormField.CustomText(fontSize: 20),
                                            ),
                                          );
                                        }).toList(),
                                        onChanged: (value) {
                                          setState(() {
                                            selectedCity = value!;
                                          });
                                        },
                                        decoration: const InputDecoration(
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(color: Colors.yellowAccent),
                                          ),
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(color: Colors.yellowAccent),
                                          ),
                                        ),
                                        dropdownColor: Colors.black,
                                        style: const TextStyle(color: Colors.white),
                                        iconEnabledColor: Colors.yellowAccent,
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                            const SizedBox(height: 20),

                            SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton(
                                style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all<Color>(Colors.yellowAccent),
                                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      side: const BorderSide(color: Colors.yellowAccent, width: 2),
                                    ),
                                  ),
                                ),
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {
                                    _formKey.currentState!.save();
                                    getuserInfo();

                                  }
                                },
                                child: const Text(
                                  "Log In",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (_isLoading)
              const Center(child: CircularProgressIndicator(color: Colors.yellowAccent,)),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(BuildContext context, {required String label, required Widget child}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          flex: 1,
          child: Text(
            label,
            style: CustomTextFormField.CustomText(fontSize: 20,color: Colors.yellowAccent,fontWeight: FontWeight.bold),
          ),
        ),
        Expanded(
          flex: 2,
          child: child,
        ),
      ],
    );
  }
}
