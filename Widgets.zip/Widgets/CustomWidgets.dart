import 'package:flutter/material.dart';

class CustomTextFormField {
  static TextFormField customTextFormField({
    required String hintText,
    required IconData prefixIcon,
    required String? Function(String?) validator,
    required void Function(String?) onSaved,
    TextInputType? keyboardType,
    bool obscureText = false,
  }) {
    return TextFormField(
      keyboardType: keyboardType,
      obscureText: obscureText,
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: const TextStyle(color: Colors.white, fontSize: 25),
        prefixIcon: Icon(
          prefixIcon,
          color: Colors.yellow,
        ),
        filled: true,
        fillColor: Colors.black,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(
            color: Colors.yellowAccent,
            width: 4,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(
            color: Colors.yellowAccent,
            width: 4,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(
            color: Colors.yellowAccent,
            width: 4,
          ),
        ),
      ),
      style: const TextStyle(fontSize: 25, color: Colors.white),
      validator: validator,
      onSaved: onSaved,
    );
  }
  static TextStyle CustomText({
    required double fontSize,
     FontWeight? fontWeight,
    String? fontFamily,
     Color? color,
  }) {
    return TextStyle(
      fontSize: fontSize,
      fontWeight: fontWeight,
      fontFamily: fontFamily,
      color: color,
    );
  }
}
