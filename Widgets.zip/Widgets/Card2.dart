import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
import 'package:uberclone/Widgets/CustomWidgets.dart';

class ForumCard extends StatefulWidget {
  final String title;
  final String image;
  final String body;
  final String email;

  ForumCard({super.key, required this.title, required this.image, required this.body, required this.email});

  @override
  State<ForumCard> createState() => _ForumCardState();
}

class _ForumCardState extends State<ForumCard> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Card(
        color: Colors.black, // Set background color to black
        elevation: 4.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
          side: BorderSide(color: Colors.yellowAccent, width: 2.0), // Yellow border
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                widget.email,
                style: CustomTextFormField.CustomText(
                  fontSize: 24.0,
                  fontFamily: "bungee",
                  color: Colors.white, // White font color for the title
                ),
              ),
            ),
            // Image section with fixed size
            Container(

              margin: EdgeInsets.all(30),
              width: MediaQuery.of(context).size.width,
              constraints: BoxConstraints(
                maxHeight: 300.0,
                minHeight: 300.0,
              ),
              child: ClipRRect(

                      borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  widget.image,
                  height: 300,
                  fit: BoxFit.fill,
                ),
              ),
            ),
            // Title section
            Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                widget.title,
                style: CustomTextFormField.CustomText(
                  fontSize: 24.0,
                  fontFamily: "bungee",
                  color: Colors.white, // White font color for the title
                ),
              ),
            ),
            // Body section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                widget.body,
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.yellowAccent, // YellowAccent color for the body text
                ),
              ),
            ),
            SizedBox(height: 8.0), // Adding space at the bottom
          ],
        ),
      ),
    );
  }
}
