import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:telephony/telephony.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:uberclone/Widgets/CustomWidgets.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';

import '../Local/SharedPreference.dart';
import '../Local/send_notification_service.dart';

class Card1 extends StatefulWidget {
  final String path;
  final String name;
  final String tagLine;
  final bool service;
  final String phoneNo;
  final String token;

  Card1({
    super.key,
    required this.path,
    required this.name,
    required this.tagLine,
    required this.service,
    required this.phoneNo,
    required this.token,
  });

  @override
  State<Card1> createState() => _Card1State();
}

class _Card1State extends State<Card1> {
  final Telephony telephony = Telephony.instance;
  String? url;
  String? email;
  String? name;
  String? city;
  String? state;
  String? service;
  final String Date=DateTime.now().toString();
  User? user = FirebaseAuth.instance.currentUser;

  Future<void> callUser(String num) async {
    try {
      bool? res = await FlutterPhoneDirectCaller.callNumber(num);
      if (res == null || !res) {
        print('Could not launch $num');
      }
    } catch (e) {
      print('Error launching phone: $e');
    }
  }

  Future<void> EmergencyData() async {
    final userId = user!.uid;
    final service = widget.name.toString();
    setState(() {
      this.service=service;
    });

    try {

      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection("Emergency")
          .where("userid", isEqualTo: userId)
          .where("service", isEqualTo: service)
          .get();

      if (querySnapshot.docs.isEmpty) {

        await FirebaseFirestore.instance.collection("Emergency").add({
          "email": this.email,
          "name": this.name,
          "service": service,
          "location": url.toString(),
          "city": city,
          "state": state,
          "userid": userId,
          "Date": Date,
          "confirm": false,
          "token":widget.token
        });
      } else {

        await FirebaseFirestore.instance
            .collection("Emergency")
            .doc(querySnapshot.docs.first.id)
            .update({
          "email": this.email,
          "name": this.name,
          "service": service,
          "location": url.toString(),
          "city": city,
          "state": state,
          "Date": Date,
          "confirm": false,
          "token":widget.token
        });
      }


      QuerySnapshot differentServiceQuerySnapshot = await FirebaseFirestore.instance
          .collection("Emergency")
          .where("userid", isEqualTo: userId)
          .where("service", isNotEqualTo: service)
          .get();

      if (differentServiceQuerySnapshot.docs.isNotEmpty) {

        await FirebaseFirestore.instance.collection("Emergency").add({
          "email": this.email,
          "name": this.name,
          "service": service,
          "location": url.toString(),
          "city": city,
          "state": state,
          "userid": userId,
          "Date": Date,
          "confirm": false,
          "token":widget.token
        });
      }
    } catch (e) {
      print("Error saving emergency data: $e");
    }
  }


  @override
  void initState() {
    super.initState();
    getCred();

  }

  Future<void> getCred() async {
    String? email = await SharedpreferenceClass.getUserEmail();
    String? name = await SharedpreferenceClass.getUserName();

    setState(() {
      this.email = email;
      this.name = name;
    });
  }

  Future<bool> _checkLocationPermission() async {
    if (await Permission.location.isGranted) {
      return true;
    } else {
      var status = await Permission.location.request();
      return status.isGranted;
    }
  }

  Future<Position> _getCurrentLocation() async {
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  Future<void> _fetchCityAndState(Position position) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      Placemark place = placemarks[0];
      setState(() {
        city = place.locality;
        state = place.administrativeArea;
      });
    } catch (e) {
      print("Error fetching city and state: $e");
    }
  }

  void _shareLocationViaSMS(Position position) async {
    String url = 'https://www.google.com/maps/search/?api=1&query=${position.latitude},${position.longitude}';
    String message = 'Here is my current location: $url \n for ${widget.name}';
    setState(() {
      this.url = url;
    });
    try {
      telephony.sendSms(
        to: widget.phoneNo,
        message: message,
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("SMS sent successfully")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to send SMS: $e")),
      );
    }
    log(url.toString());
    log(Date.toString());
  }

  void currentLoc() async {
    bool permissionGranted = await _checkLocationPermission();

    if (permissionGranted) {
      try {
        Position position = await _getCurrentLocation();
        await _fetchCityAndState(position);
        showBottomsheet(context, position);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error getting location: $e")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Location permission not granted")),
      );
    }
  }

  void showBottomsheet(BuildContext context, Position position) {
    final Size m = MediaQuery.of(context).size;
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      builder: (_) {
        return ListView(
          shrinkWrap: true,
          padding: EdgeInsets.only(
            top: m.height * .03,
            bottom: m.height * .05,
          ),
          children: [
            Text(
              "Choose app",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
            ),
            SizedBox(
              height: m.height * .02,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () async{
                    _shareLocationViaSMS(position);
                    EmergencyData();
                    log(widget.token);
                    Navigator.pop(context);
                    await  SendNotification.sendNotificationUsingApi(token: widget.token, title: "Reporting about ${service}", body: "Your complain about ${service} is successfully received", data: {
                      "screen":"emergency"
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    shape: CircleBorder(),
                    backgroundColor: Colors.white,
                    fixedSize: Size(m.width * .3, m.height * .15),
                  ),
                  child: Image.asset("Assets/Images/sms.png"),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.yellowAccent),
        borderRadius: BorderRadius.circular(30),
      ),
      width: widget.service == true
          ? MediaQuery.of(context).size.width * .30
          : MediaQuery.of(context).size.width * .40,
      height: widget.service == true
          ? MediaQuery.of(context).size.height * .22
          : MediaQuery.of(context).size.height * .30,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 30),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(
                widget.path,
                width: widget.service == true ? 40 : 50,
                height: widget.service == true ? 40 : 50,
              ),
            ),
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * .02,
          ),
          Text(
            widget.name,
            textAlign: TextAlign.center,
            style: CustomTextFormField.CustomText(
              fontSize: widget.service ? 15 : 25,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(
              top: 5,
              left: 10,
              right: 10,
              bottom: 5,
            ),
            child: Divider(
              color: Colors.yellowAccent,
              thickness: 3,
            ),
          ),
          widget.tagLine.isNotEmpty
              ? Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10)
                .copyWith(bottom: 10),
            child: Text(
              widget.tagLine,
              textAlign: TextAlign.center,
              style: CustomTextFormField.CustomText(
                fontSize: 14,
                color: Colors.white,
                fontWeight: FontWeight.normal,
              ),
            ),
          )
              : Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector (
                  onTap: () async {
                    currentLoc();
                  },
                  child: Icon(Icons.sms, color: Colors.white),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * .04,
                ),
                GestureDetector(
                  onTap: () {
                    if (widget.phoneNo.isNotEmpty) {
                      callUser(widget.phoneNo);
                    }
                  },
                  child: Icon(Icons.phone, color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
