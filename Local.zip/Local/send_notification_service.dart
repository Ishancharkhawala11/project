import 'package:http/http.dart' as http;
import 'package:uberclone/Local/get_service_key.dart';
import 'dart:convert';

class SendNotification {
  static Future<void> sendNotificationUsingApi(
      {required String? token,
        required String? title,
        required String? body,
        required Map<String, dynamic>? data}) async {
    String serverKey = await GetServerKey().getServerKey();
    String url = "https://fcm.googleapis.com/v1/projects/uberclpne/messages:send";

    var headers = <String, String>{
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $serverKey'
    };

    Map<String, dynamic> mess = {
      "message": {
        "token": token,
        "notification": {
          "body": body,
          "title": title
        },
        "data": data
      }
    };

    final http.Response response = await http.post(
      Uri.parse(url),
      headers: headers,
      body: jsonEncode(mess),
    );

    if (response.statusCode == 200) {
      print('Notification sent successfully');
    } else {
      print('Failed to send notification. Status code: ${response.statusCode}');
      print('Response body: ${response.body}');
    }
  }
}
