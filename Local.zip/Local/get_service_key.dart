import 'dart:developer';

import 'package:googleapis_auth/auth_io.dart';

import 'package:googleapis_auth/googleapis_auth.dart';
class GetServerKey{
  Future<String> getServerKey()async{
    final scopes = [
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/firebase.database',
      'https://www.googleapis.com/auth/firebase.messaging',
    ];
    final Client=await clientViaServiceAccount(ServiceAccountCredentials.fromJson({
      "type": "service_account",
      "project_id": "uberclpne",
      "private_key_id": "83379925e002e8a28864025775818f79f005848a",
      "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDJ4N70nhHI34pt\nChn9Pyjjd2FxKpxhbiZr4tE2eBXFGlTzxugtYELZTIpFwx+4sZpMT3EbMCmxs1Dy\n7Oql+5hzq2IJqNo+S5KSrnk+UFYe82zrGCSwLCA/2PCBfjJYmgFtwP6FYNNv5IC+\nbDwFVMTpHOvzQk/1MV84Eicelp8AaiFyzv8QLjctL6frnZqVLjIbXpopz3AaBNse\ndr7YAPBeQeuA74fg+9SCrIga24UnUeSvZTKjTn9PtDC07BZqeLBQiwBqoNaxd3qg\nkImSlU/T35KPu+h352jYktRsNYp2N2LRIQlaj4s4LIfwvEiQ1QU8Fw2wLqtoTq/y\numkROabjAgMBAAECggEADzC6gLw8KQSZDTy2A+udZLBLnBD8FLYNx2RudaNyOpM7\n/TPkWIsREfoZFXK/Ok3dhwxwkv58GgDyKwqksA9PGLUL+soX0e7XJ+5fn866YY3T\njkUSIvzPAxQ3KfyYRo51Y7rNQWADHjzwFbld3Xt+wu5dhWph9diHNQLjVVaOvvXF\nybLKlrrup7Tkxgg0t7f9sSs4g9u5Ccjmm09BYjska4C2kpXKPAjlOCSuFLY7HolS\nowP8SsyQlOOmcneOHVNtoXbTdMP6EerDFVWm6kf+zkaY/ca540yrwiPbh6w5nS5P\nX30DqJ+8gs01seNiGwMo4tJ4dQAuJAMuOrGmYys2oQKBgQDSTm1pqlL6zQDJXjs0\naeYVSe54USkDT52n7ZmtnJ8nIP/wx4nNOXm4TdBpMSAkU75kJy23e4+uZKtr1y3W\nirR3oXgzObpGNVZntUhakfNi9WRmsW7BjVMVerlGA5+YWT9ni65I2bBrSSWqg3oH\nRN1xakMuXdcgGJRV3RJy6NL/OwKBgQD1varVy3UjQFT7reZ2F8t7nsIaEpKVEOdw\nb+14bUt/u1APqgwD/8VTAdoaEJTMYoV+cCGk9NOCdD7T2HuHS4+9XJPPL1aMlGGa\nBrA9IFJE3V65/JBhIG+exXQQ+gYdXsN8cO5iNrO8XxHGhzGkrBQrXysFCbMyolbf\nyMMSvJTMeQKBgAvr3DHoMMn8wvWnPM3sztkYFseFOkDwy2wQgOyhezgZm8iHVx1m\nC6tR5eWAnmTQxnMg8Wt8OpnVJQ545SVLOY2qfojQ1elS7rH0ScSwj05lwKo9lpys\nKTCHg2cfn3VgYcK53UhN5r0+KT9wMoOk+LSMJIDFWwN7wTTY0knnPsavAoGAQTH3\nn87hnd+UbE0fplb7wilFX7trriaU8EyRmPCOJi4guHcpxunVhQcpwN6DS5Ibzoab\nNnNJpgOHI5b8dtGCKf/kqwPpF1TKbB24Jg9sJB8C4Z7zAwGi+2FxQIvEkYgxntMr\nO1095Azo313Auup4U2VlOWnwY8+T8r0Fm/PyGikCgYEAoL2KJoU/d1j0TrxRMCcz\n1eqPcQcRjzO2eujV4EjZ5bZxnq5qEhPubRn0H3Qsvwnc5M1HXlEUQFxuodIIoM3Q\nOTw6N6xNkKZFaq+3efXkG57As45gWMid9j0Hx2XRz7LYO45YD1qYa+N5qzNENrH7\n0WU/NrPi680vDS6cBgFJqfo=\n-----END PRIVATE KEY-----\n",
      "client_email": "firebase-adminsdk-r2axc@uberclpne.iam.gserviceaccount.com",
      "client_id": "111575030132937701160",
      "auth_uri": "https://accounts.google.com/o/oauth2/auth",
      "token_uri": "https://oauth2.googleapis.com/token",
      "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
      "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-r2axc%40uberclpne.iam.gserviceaccount.com",
      "universe_domain": "googleapis.com"
    }
    ), scopes);
    final accessServerKey=Client.credentials.accessToken.data;
    log(accessServerKey.toString());
    return accessServerKey;
  }
}