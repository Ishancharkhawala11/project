import 'package:firebase_messaging/firebase_messaging.dart';

class FcmService{
  static void firebaseInit(){
    FirebaseMessaging.onMessage.listen((report){
          print(report.notification!.title);
          print(report.notification!.body);
    });
  }
}