import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
class SharedpreferenceClass{
  static Future<void> setUserId(String id)async{
  SharedPreferences pref=await SharedPreferences.getInstance();
  await pref.setString('userId', id);
  }
  static Future<void> setEmail(String email)async
  {
    SharedPreferences pref=await SharedPreferences.getInstance();
    await pref.setString('userEmail', email);
  }
  static Future<void> setPass(String pass)async
  {
    SharedPreferences pref=await SharedPreferences.getInstance();
    await pref.setString('userPass', pass);
  }
  static Future<void> setname(String name) async{
    SharedPreferences pref=await SharedPreferences.getInstance();
    await pref.setString("userName", name);
  }
  static Future<String?> getUserId() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString('userId');
  }
  static Future<String?> getUserPass() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString('userPass');
  }
  static Future<String?> getUserEmail() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString('userEmail');
  }

  static Future<String?> getUserName() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString("userName");
  }
  static Future<void> clearPass() async{
    SharedPreferences pref=await SharedPreferences.getInstance();
    await pref.remove("userPass");
  }

}