import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:app_settings/app_settings.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:uberclone/Pages/Reporting.dart';

// class NotificationService {
//   FirebaseMessaging messaging = FirebaseMessaging.instance;
//   final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
//       FlutterLocalNotificationsPlugin();
//   void requestNotificatinPermision(BuildContext context) async {
//     NotificationSettings settings = await messaging.requestPermission(
//         alert: true,
//         announcement: true,
//         badge: true,
//         carPlay: true,
//         criticalAlert: true,
//         provisional: true,
//         sound: true);
//     if (settings.authorizationStatus == AuthorizationStatus.authorized) {
//       log("permission authorized" + settings.authorizationStatus.toString());
//     } else if (settings.authorizationStatus ==
//         AuthorizationStatus.provisional) {
//       log("permission provisional" + settings.authorizationStatus.toString());
//     } else {
//       ScaffoldMessenger.of(context)
//           .showSnackBar(SnackBar(content: Text("Permission not granted")));
//       log("No permision" + settings.authorizationStatus.toString());
//       Future.delayed(Duration(seconds: 2), () {
//         AppSettings.openAppSettings(type: AppSettingsType.notification);
//       });
//     }
//   }
//
// //get token
//   Future<String> getDevicetoken() async {
//     NotificationSettings settings = await messaging.requestPermission(
//         alert: true, badge: true, sound: true);
//     String? token = await messaging.getToken();
//     log(token.toString());
//     return token!;
//   }
//
// //init
//   void initLocalNotification(
//       BuildContext context, RemoteMessage message) async {
//     var androidSetting =
//         AndroidInitializationSettings("Assets/Images/fsos2.png");
//     var iosInitSetting = DarwinInitializationSettings();
//     var initializationSettings =
//         InitializationSettings(android: androidSetting, iOS: iosInitSetting);
//     await _flutterLocalNotificationsPlugin.initialize(initializationSettings,
//         onDidReceiveNotificationResponse: (paylod) {
//       handleMessage(context, message);
//         });
//   }
//
//   //firebase foreground
//   void firebaseinit(BuildContext context) {
//     FirebaseMessaging.onMessage.listen((mess) {
//       RemoteNotification? notification = mess.notification;
//       AndroidNotification? android = mess.notification!.android;
//       if (kDebugMode) {
//         log("notification title ${notification!.title}");
//         log("notification body ${notification.body}");
//       }
//       if (Platform.isIOS) {
//         iosForGroundmesseage();
//       }
//       if (Platform.isAndroid) {
//         initLocalNotification(context, mess);
//         // handleMessage(context, mess);
//         showNotification(mess);
//       }
//     });
//   }
//
// //show notification
//   Future<void> showNotification(RemoteMessage message) async {
//     AndroidNotificationChannel channel = AndroidNotificationChannel(
//         message.notification!.android!.channelId.toString(),
//         message.notification!.android!.channelId.toString(),
//         importance: Importance.high,
//         showBadge: true,
//         playSound: true);
//     AndroidNotificationDetails androidNotificationDetails =
//         AndroidNotificationDetails(
//             channel.id.toString(),
//             channel.name.toString(),
//           channelDescription: "Report",
//           importance: Importance.high,
//             priority: Priority.high,
//             playSound: true,
//           sound: channel.sound
//         );
//     DarwinNotificationDetails darwinNotificationDetails=DarwinNotificationDetails(
//       presentAlert: true,
//       presentBadge: true,
//       presentSound: true,
//     );
//     //merge both
//     NotificationDetails notificationDetails=NotificationDetails(
//       android: androidNotificationDetails,
//       iOS: darwinNotificationDetails
//     );
//     //show notification
//     Future.delayed(Duration.zero,(){
//       _flutterLocalNotificationsPlugin.show(
//           0, message.notification!.title.toString(), message.notification!.body.toString(), notificationDetails,
//       payload:"report"
//       );
//     });
//   }
//
// //background and terminate
//   Future<void> setUpInteractMessage(BuildContext context) async {
//     //back
//     FirebaseMessaging.onMessageOpenedApp.listen((message) {
//       handleMessage(context, message);
//     });
//
//     //terminate
//     FirebaseMessaging.instance.getInitialMessage().then((RemoteMessage? mess) {
//       if (mess != null && mess.data.isNotEmpty) {
//         handleMessage(context, mess);
//       }
//     });
//   }
//
//   Future<void> handleMessage(BuildContext context, RemoteMessage messge) async {
//     Navigator.push(
//         context, MaterialPageRoute(builder: (context) => Reporting()));
//   }
//
//   Future iosForGroundmesseage() async {
//     await FirebaseMessaging.instance
//         .setForegroundNotificationPresentationOptions(
//       alert: true,
//       badge: true,
//       sound: true,
//     );
//   }
// }
class NotificationService {
  FirebaseMessaging messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();

  void requestNotificationPermission(BuildContext context) async {
    NotificationSettings settings = await messaging.requestPermission(
        alert: true,
        announcement: true,
        badge: true,
        carPlay: true,
        criticalAlert: true,
        provisional: true,
        sound: true);
    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      log("Permission authorized: " + settings.authorizationStatus.toString());
    } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      log("Permission provisional: " + settings.authorizationStatus.toString());
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Permission not granted")));
      log("No permission: " + settings.authorizationStatus.toString());
      Future.delayed(Duration(seconds: 2), () {
        AppSettings.openAppSettings(type: AppSettingsType.notification);
      });
    }
  }

  // Get device token
  Future<String> getDeviceToken() async {
    String? token = await messaging.getToken();
    // log("Device token: $token");
    return token!;
  }

  // Initialize local notifications
  void initLocalNotification(BuildContext context) async {
    var androidSetting = AndroidInitializationSettings('@drawable/fsos2');
    var iosInitSetting = DarwinInitializationSettings();
    var initializationSettings =
    InitializationSettings(android: androidSetting, iOS: iosInitSetting);

    await _flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onDidReceiveNotificationResponse: (payload) {
          handleMessage(context, payload as String?);
        });
  }

  // Firebase foreground message handling
  void firebaseInit(BuildContext context) {
    FirebaseMessaging.onMessage.listen((message) {
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;

      if (notification != null && android != null) {
        showNotification(message);
      }
    });
  }

  // Show notification
  Future<void> showNotification(RemoteMessage message) async {
    AndroidNotificationChannel channel = AndroidNotificationChannel(
   "Jan-Suvidha Chennel",
     "Jan-Suvidha Notification",
      importance: Importance.high,
      playSound: true,
      showBadge: true,
    );

    AndroidNotificationDetails androidNotificationDetails =
    AndroidNotificationDetails(
      channel.id,
      channel.name,
      channelDescription: 'Channel description',
      importance: Importance.high,
      priority: Priority.high,
      playSound: true,
    );

    DarwinNotificationDetails darwinNotificationDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    NotificationDetails notificationDetails = NotificationDetails(
      android: androidNotificationDetails,
      iOS: darwinNotificationDetails,
    );

    await _flutterLocalNotificationsPlugin.show(
      message.hashCode,
      message.notification?.title,
      message.notification?.body,
      notificationDetails,
      payload: message.data['route'] ?? 'default',
    );
  }

  // Background and terminated message handling
  Future<void> setUpInteractMessage(BuildContext context) async {
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      handleMessage(context, message.data['route']);
    });

    FirebaseMessaging.instance.getInitialMessage().then((message) {
      if (message != null) {
        handleMessage(context, message.data['route']);
      }
    });
  }

  Future<void> handleMessage(BuildContext context, String? route) async {
    if (route != null) {
      Navigator.pushNamed(context, route);
    }
  }

  Future<void> iosForegroundMessage() async {
    await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }
}
