import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:uberclone/Local/Notification.dart';

import 'package:uberclone/Local/send_notification_service.dart';
import 'package:uberclone/Widgets/CustomWidgets.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:file_picker/file_picker.dart';
import 'package:geocoding/geocoding.dart';

import '../Local/SharedPreference.dart'; // Import geocoding package

class Reporting extends StatefulWidget {
  final String Token;
  const Reporting({super.key,required this.Token});

  @override
  State<Reporting> createState() => _ReportingState();
}

class _ReportingState extends State<Reporting> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  List<String> items = ["Criminal Activity", "Abusing", "Threats", "Suicide"];
  String selected = "Criminal Activity";
  TextEditingController addController = TextEditingController();
  TextEditingController incidentController = TextEditingController();
  String dateTime = DateTime.now().toString();
  String ?id;
  XFile? selectedImage;
  XFile? selectedVideo;
  XFile? selectedAudio;
  XFile? selectGallary;
  bool isLoading = false;
  String? placeState;
  String? placecity;

  NotificationService notificationService=NotificationService();
  String? token;

  double? latitude;
  double? longitude;
  User? user=FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _fetchCurrentLocation();
    // saveReport();

  }

  Future<void> getCred() async {

    String? id = await SharedpreferenceClass.getUserName();
    setState(() {
      this.id=id;
    });
  }
  // Future<void> saveReport() async {
  //   // Assuming notificationService is an instance of NotificationService
  //   final notificationService = NotificationService();
  //
  //   String deviceToken = await notificationService.getDeviceToken();
  // setState(() {
  //   this.token=deviceToken;
  // });
  // log(token.toString());
  // }
  Future<String> getAddressFromLatLng(double latitude, double longitude) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(latitude, longitude);

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks[0];
        setState(() {
          this.placeState=place.administrativeArea;
          this.placecity=place.locality;
        });
        return " ${place.street}, ${place.subLocality}, ${place.locality}, ${place.administrativeArea}, ${place.country}";
      }
      return "No address found";
    } catch (e) {
      return "Failed to get address: $e";
    }
  }

  Future<void> submitReport() async {
    if (_formKey.currentState!.validate()) {
      String address = addController.text.trim();
      String incidentDescription = incidentController.text.trim();
      String? imageUrl;
      String? videoUrl;
      String? audioUrl;

      setState(() {
        isLoading = true;
      });

      try {
        if (selectedImage != null) {
          imageUrl = await uploadImage(selectedImage!);
        }
        if (selectGallary != null) {
          imageUrl = await uploadImage(selectGallary!);
        }
        if (selectedVideo != null) {
          videoUrl = await uploadVideo(selectedVideo!);
        }
        if (selectedAudio != null) {
          audioUrl = await uploadAudio(selectedAudio!);
        }
        Map<String, dynamic> report = {
          'dateTime': dateTime,
          'address': address,
          'description': incidentDescription,
          'userId': user!.uid,
          'location': 'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude',
          'image': imageUrl,
          'video': videoUrl.toString(),
          'audio': audioUrl,
          "Activity":selected.toString(),
          'city':placecity.toString(),
          'state':placeState.toString(),
          "confirm":false,
          "deviceToken":widget.Token,

        };

        final querySnapshot = await FirebaseFirestore.instance
            .collection("report")
            .where("userId", isEqualTo: user!.uid).where("Activity",isEqualTo: selected)
            .limit(1)
            .get();

        if (querySnapshot.docs.isNotEmpty) {

          await querySnapshot.docs.first.reference.update(report);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Report updated successfully!')),
          );
        } else {

          DocumentReference newReportRef = await FirebaseFirestore.instance.collection("report").add(report);

          report['documentId'] = newReportRef.id; // Add the document ID here

          await newReportRef.update({'documentId': newReportRef.id}); // Update the document to include the ID
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Report submitted successfully!')),
          );
        }

        // Clear the form fields after submission

        addController.clear();
        incidentController.clear();
        setState(() {
          selectedImage = null;
          selectedVideo = null;
          selectedAudio = null;
          selectGallary = null;
        });
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to submit report: $e')),
        );
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<String> uploadImage(XFile image) async {
    Reference storageRef = FirebaseStorage.instance
        .ref()
        .child("reports/images/${DateTime.now().millisecondsSinceEpoch}.jpg");
    UploadTask upload = storageRef.putFile(File(image.path));
    TaskSnapshot snapshot = await upload;
    return await snapshot.ref.getDownloadURL();
  }

  Future<String> uploadVideo(XFile video) async {
    Reference storageRef = FirebaseStorage.instance
        .ref()
        .child("reports/videos/${DateTime.now().millisecondsSinceEpoch}.mp4");
    UploadTask upload = storageRef.putFile(File(video.path));
    TaskSnapshot snapshot = await upload;
    return await snapshot.ref.getDownloadURL();
  }

  Future<String> uploadAudio(XFile audio) async {
    Reference storageRef = FirebaseStorage.instance
        .ref()
        .child("reports/audios/${DateTime.now().millisecondsSinceEpoch}.mp4");
    UploadTask upload = storageRef.putFile(File(audio.path));
    TaskSnapshot snapshot = await upload;
    return await snapshot.ref.getDownloadURL();
  }

  Future<bool> _checkLocationPermission() async {
    if (await Permission.location.isGranted) {
      return true;
    } else {
      var status = await Permission.location.request();
      return status.isGranted;
    }
  }

  Future<Position> _getCurrentLocation() async {
    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
  }

  void _fetchCurrentLocation() async {
    bool permissionGranted = await _checkLocationPermission();

    if (permissionGranted) {
      try {
        Position position = await _getCurrentLocation();
        setState(() {
          latitude = position.latitude;
          longitude = position.longitude;
        });

        // Fetch the address and update the TextFormField
        String address = await getAddressFromLatLng(latitude!, longitude!);
        setState(() {
          addController.text = address;
        });
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error getting location: $e")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Location permission not granted")),
      );
    }
  }

  Future<void> pickImage(ImageSource source, String path) async {
    final ImagePicker picker = ImagePicker();
    final XFile? file = await picker.pickImage(source: source, imageQuality: 80);

    if (file != null) {
      setState(() {
        path == "Assets/Images/camera.png" ? selectedImage = file : selectGallary = file;
      });
    }
  }

  Future<void> pickVideo(ImageSource source) async {
    final ImagePicker picker = ImagePicker();
    final XFile? file = await picker.pickVideo(source: source);

    if (file != null) {
      setState(() {
        selectedVideo = file;
      });
    }
  }

  Future<void> pickAudio() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result != null) {
      File file = File(result.files.single.path!);
      log(file.toString());
      setState(() {
        selectedAudio = XFile(file.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: isLoading
            ? const Center(child: CircularProgressIndicator())
            : Container(
          margin: EdgeInsets.only(
            top: MediaQuery.of(context).size.height * .02,
            left: MediaQuery.of(context).size.width * .04,
            right: MediaQuery.of(context).size.width * .04,
          ),
          padding: EdgeInsets.symmetric(
            vertical: MediaQuery.of(context).size.height * .04,
            horizontal: MediaQuery.of(context).size.width * .06,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                          Future.delayed(const Duration(milliseconds: 500), () {
                            Navigator.pop(context);
                          });
                        },
                        child: Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: Colors.yellowAccent),
                      ),
                      Expanded(
                        child: Text(
                          "Reporting Incident",
                          textAlign: TextAlign.center,
                          style: CustomTextFormField.CustomText(
                            fontSize: 40,
                            fontFamily: "Bungee",
                            color: Colors.yellowAccent,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: MediaQuery.of(context).size.height * .025),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildRow(
                          context,
                          label: "Date and Time:",
                          child: Text(
                            dateTime,
                            style: CustomTextFormField.CustomText(
                              fontSize: 20,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height * .02),
                        _buildRow(
                          context,
                          label: "Address",
                          child: TextFormField(
                            controller: addController,
                            cursorColor: Colors.yellowAccent,
                            decoration: InputDecoration(
                              hintText: "Enter Address",
                              hintStyle: const TextStyle(color: Colors.white),
                              border: const UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.yellowAccent,
                                ),
                              ),
                              enabledBorder: const UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.yellowAccent,
                                ),
                              ),
                              focusedBorder: const UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.yellowAccent,
                                  width: 2.0,
                                ),
                              ),
                            ),
                            style: const TextStyle(color: Colors.white),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter an address';
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height * .02),
                        _buildRow(
                          context,
                          label: "Select Activity",
                          child: DropdownButtonFormField<String>(
                            value: selected,
                            items: items.map((item) {
                              return DropdownMenuItem<String>(
                                value: item,
                                child: Text(
                                  item,
                                  style: CustomTextFormField.CustomText(fontSize: 20),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                selected = value!;
                              });
                            },
                            decoration: const InputDecoration(
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: Colors.yellowAccent),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: Colors.yellowAccent),
                              ),
                            ),
                            dropdownColor: Colors.black,
                            style: const TextStyle(color: Colors.white),
                            iconEnabledColor: Colors.yellowAccent,
                            alignment: AlignmentDirectional.bottomStart,
                          ),
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height * .02),
                        _buildRow(
                          context,
                          label: "Location",
                          child: latitude != null && longitude != null
                              ? Text(
                            "Lat: $latitude, Lng: $longitude",
                            style: CustomTextFormField.CustomText(
                                fontSize: 20, color: Colors.white),
                          )
                              : const Text(
                            "Fetching location...",
                            style: TextStyle(fontSize: 20, color: Colors.white),
                          ),
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height * .05),
                        TextFormField(
                          controller: incidentController,
                          cursorColor: Colors.yellowAccent,
                          decoration: InputDecoration(
                            hintText: "Write About Incident",
                            hintStyle: const TextStyle(color: Colors.white),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: const BorderSide(color: Colors.yellowAccent),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: const BorderSide(color: Colors.yellowAccent),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: const BorderSide(color: Colors.yellowAccent),
                            ),
                          ),
                          maxLines: 6,
                          style: const TextStyle(color: Colors.white),
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height * .05),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: () => pickImage(ImageSource.camera, "Assets/Images/camera.png"),
                              child: _buildImageContainer("Assets/Images/camera.png"),
                            ),
                            GestureDetector(
                              onTap: () => pickImage(ImageSource.gallery, "Assets/Images/galary.png"),
                              child: _buildImageContainer("Assets/Images/galary.png"),
                            ),
                            GestureDetector(
                              onTap: () => pickVideo(ImageSource.gallery),
                              child: _buildImageContainer("Assets/Images/video.png"),
                            ),
                            GestureDetector(
                              onTap: () => pickAudio(),
                              child: _buildImageContainer("Assets/Images/audio.png"),
                            ),
                          ],
                        ),
                        SizedBox(height: MediaQuery.of(context).size.height * 0.03),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(Colors.yellowAccent),
                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                  side: const BorderSide(color: Colors.yellowAccent, width: 4),
                                ),
                              ),
                            ),
                            onPressed: ()async{
                             await submitReport();
                              await  SendNotification.sendNotificationUsingApi(token: widget.Token, title: "Reporting about ${selected}", body: "Your complain about ${selected} is successfully received", data: {
                                "screen":"reporting"
                              });
                            },
                            child: const Text(
                              "Submit",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRow(BuildContext context, {required String label, required Widget child}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: MediaQuery.of(context).size.width * 0.3,
          child: Text(
            label,
            style: CustomTextFormField.CustomText(fontSize: 20, color: Colors.white),
          ),
        ),
        SizedBox(width: MediaQuery.of(context).size.width * 0.02),
        Expanded(child: child),
      ],
    );
  }

  Widget _buildImageContainer(String imagePath) {
    if (imagePath == "Assets/Images/camera.png") {
      return selectedImage != null
          ? Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.yellowAccent),
          borderRadius: BorderRadius.circular(20),
        ),
        width: 70,
        height: 70,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Image.file(File(selectedImage!.path)),
        ),
      )
          : defaultContainer(imagePath);
    } else if (imagePath == "Assets/Images/galary.png") {
      return selectGallary != null
          ? Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.yellowAccent),
          borderRadius: BorderRadius.circular(20),
        ),
        width: 70,
        height: 70,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Image.file(File(selectGallary!.path)),
        ),
      )
          : defaultContainer(imagePath);
    } else if (imagePath == "Assets/Images/video.png") {
      return selectedVideo != null
          ? Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.yellowAccent),
          borderRadius: BorderRadius.circular(20),
        ),
        width: 70,
        height: 70,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: const Icon(Icons.video_library, color: Colors.white),
        ),
      )
          : defaultContainer(imagePath);
    } else if (imagePath == "Assets/Images/audio.png") {
      return selectedAudio != null
          ? Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.yellowAccent),
          borderRadius: BorderRadius.circular(20),
        ),
        width: 70,
        height: 70,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: const Icon(Icons.audiotrack, color: Colors.white),
        ),
      )
          : defaultContainer(imagePath);
    } else {
      return defaultContainer(imagePath);
    }
  }

  Widget defaultContainer(String imagePath) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.yellowAccent),
        borderRadius: BorderRadius.circular(20),
      ),
      width: 70,
      height: 70,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Image.asset(imagePath),
      ),
    );
  }
}
