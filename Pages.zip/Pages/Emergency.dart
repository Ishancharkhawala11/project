import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:uberclone/Widgets/Card.dart';
import 'package:uberclone/Widgets/CustomWidgets.dart';

import '../Local/SharedPreference.dart';

class Emergency extends StatefulWidget {
  final String? token;
  const Emergency({super.key, this.token});

  @override
  State<Emergency> createState() => _EmergencyState();
}

class _EmergencyState extends State<Emergency> {
  User? user = FirebaseAuth.instance.currentUser;
  String? emergencyNo;
  String? type;
  String? email;
  String? name;


  Future<void> getUserInfo() async {

    if (user != null) {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection("users").doc(user!.uid).get();
      if (userDoc.exists) {
        setState(() {
          emergencyNo = userDoc["emergencyNumber"];
          log("Emergency Number: $emergencyNo");
        });
      } else {
        log("User document does not exist");
      }
    }
  }

  @override
  void initState() {
    super.initState();
    getUserInfo();
    log("emergency token "+widget.token.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        margin: EdgeInsets.only(
          right: MediaQuery.of(context).size.width * 0.02,
          left: MediaQuery.of(context).size.width * 0.02,
        ),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(
                top: MediaQuery.of(context).size.height * .05,
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back_ios_new_rounded,
                      color: Colors.yellowAccent,
                    ),
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * .04,
                  ),
                  Text(
                    "SOS Services",
                    style: CustomTextFormField.CustomText(
                      fontSize: 40,
                      color: Colors.yellowAccent,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Bungee",
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: MediaQuery.of(context).size.height * .06),
            Row(
              children: [
                Card1(
                  phoneNo: emergencyNo ?? "",
                  path: "Assets/Images/home_call.png",
                  name: "Home",
                  tagLine: "",
                  service: true,
                  token: widget.token.toString(),
                ),
                SizedBox(width: MediaQuery.of(context).size.width * .02),
                Card1(
                  // phoneNo: "8780383259",
                  phoneNo: "9925100624",
                  path: "Assets/Images/ambulance.png",
                  name: "Ambulance",
                  tagLine: "",
                  service: true,
                  token: widget.token.toString(),
                ),
                SizedBox(width: MediaQuery.of(context).size.width * .02),
                Card1(
                  // phoneNo: "8780383259",
                  phoneNo: "9925100624",
                  path: "Assets/Images/fire_call.png",
                  name: "Fire",
                  tagLine: "",
                  service: true,
                  token: widget.token!,
                ),
              ],
            ),
            SizedBox(height: MediaQuery.of(context).size.height * .03),
            Row(
              children: [
                Card1(
                  // phoneNo: "8780383259",
                  phoneNo: "9925100624",
                  path: "Assets/Images/police_call.png",
                  name: "Police",
                  tagLine: "",
                  service: true,
                  token: widget.token!,
                ),
                SizedBox(width: MediaQuery.of(context).size.width * .02),
                Card1(
                  // phoneNo:"8780383259",
                  phoneNo: "9925100624",
                  path: "Assets/Images/women_call.png",
                  name: "Women Help",
                  tagLine: "",
                  service: true,
                  token: widget.token!,
                ),
                SizedBox(width: MediaQuery.of(context).size.width * .02),
                Card1(
                  // phoneNo: "8780383259",
                  phoneNo: "9925100624",
                  path: "Assets/Images/child_call.png",
                  name: "Child Help",
                  tagLine: "",
                  service: true,
                  token: widget.token!,
                ),
              ],
            ),
            SizedBox(height: MediaQuery.of(context).size.height * .03),
            Row(
              children: [
                Card1(
                  // phoneNo: "8780383259",
                  phoneNo: "9925100624",
                  path: "Assets/Images/wildlife_call.png",
                  name: "WildLife Supporter",
                  tagLine: "",
                  service: true,
                  token: widget.token!,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
