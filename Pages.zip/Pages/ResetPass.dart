import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../Local/SharedPreference.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
class ForgotPass extends StatefulWidget {
  const ForgotPass({super.key});

  @override
  State<ForgotPass> createState() => _ForgotPassState();
}

class _ForgotPassState extends State<ForgotPass> {
  String? email;
  TextEditingController Email=TextEditingController();
  final _formKey = GlobalKey<FormState>();
  resetpass()async{
    try{
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email!);
      await SharedpreferenceClass.clearPass();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
            "Password Reset link is send to your Email",
            style: TextStyle(fontSize: 20),
          )));

    }on FirebaseAuthException catch(e){
      if(e.code=='user-not-found')
      {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
              "No user found for the Email",
              style: TextStyle(fontSize: 20),
            )));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        body: Container(

            child: Column(
              children: [
                SizedBox(
                  height: 70,
                ),
                Container(
                  alignment: Alignment.topCenter,
                  child: Text("Password Recovery",style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold),),
                ),
                SizedBox(height: 10,),
                Text("Enter your email",style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold),),
                SizedBox(height: 30,),
                Form(
                  key: _formKey,
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 20),
                    padding:EdgeInsets.only(left: 10) ,
                    decoration: BoxDecoration(
                        border: Border.all(color:Colors.white70,width: 2 ),
                        borderRadius: BorderRadius.circular(30)
                    ),
                    child: TextFormField(
                      validator: (value)
                      {
                        if(value==null || value.isEmpty)
                        {
                          return "Enter your Email";
                        }
                        return null;
                      },
                      controller: Email,
                      style: TextStyle(
                          color: Colors.white
                      ),
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Enter your Email",
                          hintStyle: TextStyle(fontSize: 18,color: Colors.white),
                          prefixIcon: Icon(Icons.mail_outline,color: Colors.white70,size: 30,)
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20,),
                GestureDetector(
                  onTap: () {
                    if(_formKey.currentState!.validate())
                    {
                      setState(() {
                        email=Email.text;
                      });
                      resetpass();
                    }

                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 30,vertical: 10),
                    decoration: BoxDecoration(
                        color: Color(0xFFdf711a),
                        borderRadius: BorderRadius.circular(30)
                    ),
                    child: Text(
                      "Send Email",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
    ));

  }
}
