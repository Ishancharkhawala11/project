import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:uberclone/Pages/Home.dart';
import 'package:uberclone/Pages/Login.dart';
import '../Local/SharedPreference.dart';
import '../Widgets/CustomWidgets.dart';

class GetRegister extends StatefulWidget {
  const GetRegister({super.key});

  @override
  State<GetRegister> createState() => _GetRegisterState();
}

class _GetRegisterState extends State<GetRegister> {
  final _formKey = GlobalKey<FormState>();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String gender = "Male";
  String? fullName;
  String? email;
  String? password;
  String? mobileNo;
  String? address;
  String? emergencyNumber;

  Future<bool> _checkInternetConnectivity() async {
    try {
      final response = await http.get(Uri.parse('https://www.google.com'));
      if (response.statusCode == 200) {
        return true;
      }
    } catch (e) {
      log("No internet connection: $e");
    }
    return false;
  }

  Future<void> createAccount() async {
    bool isConnected = await _checkInternetConnectivity();
    if (!isConnected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No internet connection")),
      );
      return;
    }

    try {
      FocusScope.of(context).unfocus();
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email!,
        password: password!,
      );


      await _firestore.collection('users').doc(userCredential.user!.uid).set({
        'fullName': fullName,
        'email': email,
        'gender': gender,
        'mobileNo': mobileNo,
        'address': address,
        'emergencyNumber': emergencyNumber,
      });
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user!.uid)
          .get();
      String fulName = userDoc['fullName'];
      log(fulName);


      await SharedpreferenceClass.setUserId(userCredential.user!.uid);
      await SharedpreferenceClass.setEmail(email!);
      await SharedpreferenceClass.setPass(password!);
      await SharedpreferenceClass.setname(fulName);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Account created successfully!")),
      );


      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const Home(isAdmin: false,)),
            (Route<dynamic> route) => false,
      );
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to create account: ${e.message}")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("An error occurred: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Container(
          margin: const EdgeInsets.only(top: 5, left: 20, right: 20),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height * .049),
                alignment: Alignment.center,
                child: const Text(
                  "Get Registered!!",
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Bungee"),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .02),
                            CustomTextFormField.customTextFormField(
                              hintText: "Full name",
                              prefixIcon: Icons.person_outline,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your full name';
                                }
                                fullName = value;
                                return null;
                              },
                              onSaved: (value) => fullName = value,
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .02),
                            CustomTextFormField.customTextFormField(
                              hintText: "Email",
                              prefixIcon: Icons.email_outlined,
                              keyboardType: TextInputType.emailAddress,
                              validator: (value) {
                                if (value == null ||
                                    value.isEmpty ||
                                    !RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                                        .hasMatch(value)) {
                                  return 'Please enter a valid email address';
                                }
                                email = value;
                                return null;
                              },
                              onSaved: (value) => email = value,
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .02),
                            CustomTextFormField.customTextFormField(
                              hintText: "Password",
                              prefixIcon: Icons.password_outlined,
                              obscureText: true,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter a password';
                                } else if (value.length < 6) {
                                  return 'Password must be at least 6 characters long';
                                }
                                password = value;
                                return null;
                              },
                              onSaved: (value) => password = value,
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .02),
                            CustomTextFormField.customTextFormField(
                              hintText: "Mobile No",
                              prefixIcon: Icons.phone_android_rounded,
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your mobile number';
                                } else if (!RegExp(r'^\d{10}$')
                                    .hasMatch(value)) {
                                  return 'Please enter a valid 10-digit mobile number';
                                }
                                mobileNo = value;
                                return null;
                              },
                              onSaved: (value) => mobileNo = value,
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .02),
                            CustomTextFormField.customTextFormField(
                              hintText: "Address",
                              prefixIcon: Icons.location_on_outlined,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your address';
                                }
                                address = value;
                                return null;
                              },
                              onSaved: (value) => address = value,
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .02),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: Colors.yellowAccent,
                                  width: 4,
                                ),
                              ),
                              child: Column(
                                children: [
                                  const Text(
                                    "Select your gender:",
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 20),
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Radio(
                                        activeColor: Colors.yellowAccent,
                                        value: "Male",
                                        groupValue: gender,
                                        onChanged: (value) {
                                          setState(() {
                                            gender = value.toString();
                                          });
                                          log(gender);
                                        },
                                      ),
                                      const Text(
                                        "Male",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 20),
                                      ),
                                      Radio(
                                        activeColor: Colors.yellowAccent,
                                        value: "Female",
                                        groupValue: gender,
                                        onChanged: (value) {
                                          setState(() {
                                            gender = value.toString();
                                          });
                                          log(gender);
                                        },
                                      ),
                                      const Text(
                                        "Female",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 20),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .02),
                            CustomTextFormField.customTextFormField(
                              hintText: "Emergency Number",
                              prefixIcon: Icons.phone_android_outlined,
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter an emergency contact number';
                                } else if (!RegExp(r'^\d{10}$')
                                    .hasMatch(value)) {
                                  return 'Please enter a valid 10-digit number';
                                } else if (value == mobileNo) {
                                  return 'Emergency number cannot be the same as mobile number';
                                }
                                emergencyNumber = value;
                                return null;
                              },
                              onSaved: (value) => emergencyNumber = value,
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .03),
                            SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton(
                                style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all<Color>(
                                      Colors.yellowAccent),
                                  shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                      side: const BorderSide(
                                          color: Colors.yellowAccent, width: 4),
                                    ),
                                  ),
                                ),
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {
                                    _formKey.currentState!.save();
                                    createAccount();
                                  }
                                },
                                child: const Text(
                                  "Register",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 25,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            SizedBox(
                                height: MediaQuery.of(context).size.height * .01),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                const Text(
                                  "Already have an account??",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    // Navigate to Login screen and clear the back stack
                                    Navigator.pushAndRemoveUntil(
                                      context,
                                      MaterialPageRoute(builder: (_) => const Login()),
                                          (Route<dynamic> route) => false,
                                    );
                                  },
                                  child: const Text(
                                    " LogIn",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
