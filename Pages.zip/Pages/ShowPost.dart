import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uberclone/Widgets/Card2.dart';
import 'package:uberclone/Widgets/CustomWidgets.dart';

class ShowPost extends StatefulWidget {
  final String email;
  const ShowPost({super.key, required this.email});

  @override
  State<ShowPost> createState() => _ShowPostState();
}

class _ShowPostState extends State<ShowPost> {
  // Fetch posts from Firestore
  Stream<List<Map<String, dynamic>>> getPosts() {
    return FirebaseFirestore.instance.collection('posts').snapshots().map(
          (snapshot) => snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        // Add doc ID if needed (for later reference)
        return {
          ...data,
          'id': doc.id,
        };
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.yellowAccent),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          "Posts",
          style: TextStyle(
            color: Colors.yellowAccent,
            fontSize: 24,
            fontFamily: "Bungee",
          ),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.black,
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: getPosts(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Text(
                'No posts available.',
                style: CustomTextFormField.CustomText(fontSize: 26, color: Colors.yellowAccent, fontWeight: FontWeight.bold),
              ),
            );
          } else {
            final List<Map<String, dynamic>> posts = snapshot.data!;

            return ListView.builder(
              itemCount: posts.length,
              itemBuilder: (context, index) {
                final post = posts[index];
                return ForumCard(
                  title: post['title'] ?? 'No Title',
                  image: post['image'] ?? 'Assets/Images/placeholder.png',
                  body: post['body'] ?? 'No Description',
                  email: post['email'] ?? 'No Email', // Add email to ForumCard
                );
              },
            );
          }
        },
      ),
    );
  }
}
