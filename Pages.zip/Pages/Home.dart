import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart'; // Add this package to check connectivity
import 'package:flutter/material.dart';
import 'package:uberclone/Local/FCM_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uberclone/Pages/Login.dart';
import 'package:uberclone/Pages/Emergency.dart';
import 'package:uberclone/Pages/Reporting.dart';
import 'package:uberclone/Pages/profile.dart';
import 'package:uberclone/Widgets/Card.dart';

import '../Admin/AdminCredConform.dart';
import '../Local/Notification.dart';
import '../Local/send_notification_service.dart';
import 'FOrum.dart';

class Home extends StatefulWidget {
  final bool isAdmin;

  const Home({super.key, required this.isAdmin});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String? username;
  String? password;
  bool Admin = false;
  String? token;

  NotificationService service = NotificationService();

  @override
  void initState() {
    super.initState();
    service.requestNotificationPermission(context);
    _initializeToken();
    service.firebaseInit(context);
    service.setUpInteractMessage(context);
    service.initLocalNotification(context);
    if (widget.isAdmin) _listenForEmergencyData();
    if (widget.isAdmin) _listenforReportData();
  }

  Future<void> _initializeToken() async {
    String? deviceToken = await service.getDeviceToken();
    setState(() {
      token = deviceToken;
    });
    if (token != null) {
      print(token!);
    }
  }

  Future<bool> _isOnline() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    return connectivityResult != ConnectivityResult.none;
  }

  Future<void> _listenForEmergencyData() async {
    bool isOnline = await _isOnline();
    Duration duration = isOnline ? Duration(minutes: 2) : Duration(minutes: 60);

    FirebaseFirestore.instance.collection("Emergency").snapshots().listen((snapshot) {
      DateTime now = DateTime.now();
      DateTime halfHourAgo = now.subtract(duration);

      for (var doc in snapshot.docs) {
        String dateString = doc["Date"]; // Assuming the document has a "date" field as a string
        DateTime docTime = DateTime.parse(dateString);

        if (docTime.isAfter(halfHourAgo) && docTime.isBefore(now)) {
          _sendEmergencyNotification(doc); // Send notification for documents within the last half hour
        }
      }
    });
  }

  Future<void> _listenforReportData() async {
    bool isOnline = await _isOnline();
    Duration duration = isOnline ? Duration(minutes: 2) : Duration(minutes: 60);

    FirebaseFirestore.instance.collection("report").snapshots().listen((snapshot) {
      DateTime now = DateTime.now();
      DateTime halfHourAgo = now.subtract(duration);

      for (var doc in snapshot.docs) {
        String dateStrig = doc["dateTime"];
        DateTime docTime = DateTime.parse(dateStrig);

        if (docTime.isAfter(halfHourAgo) && docTime.isBefore(now)) {
          _sendReportNotification(doc);
        }
      }
    });
  }

  Future<void> _sendEmergencyNotification(DocumentSnapshot doc) async {
    String serviceName = doc["service"] ?? "Emergency Service"; // Service name in Emergency document
    String title = "New Service Request: $serviceName";

    // Send notification to the device
    if (token != null) {
      SendNotification.sendNotificationUsingApi(
          title: title,
          body: "A new emergency request has been received.",
          token: token!,
          data: {"screen": "home"});
    }
  }

  Future<void> _sendReportNotification(DocumentSnapshot doc) async {
    String serviceName = doc["Activity"] ?? "Reporting";
    String title = "New Report Request: $serviceName";
    if (token != null) {
      SendNotification.sendNotificationUsingApi(
          title: title,
          body: "A new Report request has been received.",
          token: token!,
          data: {"screen": "home"});
    }
  }

  Future<void> _logOut() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => Login()),
    );
  }

  Future<bool> _onWillPop() async {
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: token == null
            ? Center(child: CircularProgressIndicator())
            : Container(
          margin: EdgeInsets.symmetric(
            horizontal: MediaQuery.of(context).size.width * 0.07,
          ),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(
                  top: MediaQuery.of(context).size.height * 0.05,
                ),
                child: Row(
                  children: [
                    Image.asset(
                      "Assets/Images/fsos2.png",
                      width: 55,
                      height: 55,
                    ),
                    Text(
                      "Services",
                      style: TextStyle(
                        fontSize: MediaQuery.of(context).size.height * 0.057,
                        fontFamily: "Bungee",
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.06),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Emergency(token: token.toString())),
                          );
                        },
                        child: Card1(
                          phoneNo: "",
                          service: false,
                          name: "Emergency",
                          path: "Assets/Images/em1.png",
                          tagLine: "Are you in trouble? Send Emergency signal.",
                          token: token.toString(),
                        ),
                      ),
                      SizedBox(width: MediaQuery.of(context).size.width * 0.04),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Reporting(Token: token.toString())),
                          );
                        },
                        child: Card1(
                          phoneNo: "",
                          service: false,
                          name: "Reporting",
                          path: "Assets/Images/reporting.png",
                          tagLine: "Want to report an Incident?",
                          token: token.toString(),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Forum()),
                          );
                        },
                        child: Card1(
                          phoneNo: "",
                          service: false,
                          name: "Forum",
                          path: "Assets/Images/forum.png",
                          tagLine: "Get your task here",
                          token: token.toString(),
                        ),
                      ),
                      SizedBox(width: MediaQuery.of(context).size.width * 0.04),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => Profile()),
                          );
                        },
                        child: Card1(
                          phoneNo: "",
                          service: false,
                          name: "Profile",
                          path: "Assets/Images/profile.png",
                          tagLine: "Manage your profile Here",
                          token: token.toString(),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              widget.isAdmin
                  ? SizedBox(height: MediaQuery.of(context).size.height * 0.04)
                  : SizedBox(height: MediaQuery.of(context).size.height * 0.07),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.yellowAccent),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        side: const BorderSide(
                          color: Colors.yellowAccent,
                          width: 4,
                        ),
                      ),
                    ),
                  ),
                  onPressed: _logOut,
                  child: const Text(
                    "Log Out",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              widget.isAdmin
                  ? SizedBox(height: MediaQuery.of(context).size.height * 0.02)
                  : SizedBox(height: 0),
              widget.isAdmin
                  ? SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.yellowAccent),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        side: const BorderSide(
                          color: Colors.yellowAccent,
                          width: 4,
                        ),
                      ),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => AdminLog()),
                    );
                  },
                  child: const Text(
                    "Admin",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              )
                  : SizedBox(width: 0, height: 0),
            ],
          ),
        ),
      ),
    );
  }
}
