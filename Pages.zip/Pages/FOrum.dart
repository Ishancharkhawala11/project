import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:uberclone/Pages/ShowPost.dart';
import 'package:uberclone/Widgets/CustomWidgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../Local/SharedPreference.dart';

class Forum extends StatefulWidget {
  const Forum({super.key});

  @override
  State<Forum> createState() => _ForumState();
}

class _ForumState extends State<Forum> {
  final _formKey = GlobalKey<FormState>();
  String? title;
  String? body;
  XFile? selectedImage;
  final ImagePicker imagePicker = ImagePicker();
  bool isLoading = false;
  final userId = FirebaseAuth.instance.currentUser?.uid;
  String? email;
  final userEmail = FirebaseAuth.instance.currentUser?.email;

  Future<void> getCred() async {
    String? email = await SharedpreferenceClass.getUserEmail();
    setState(() {
      this.email = email;
    });
  }

  Future<void> pickImage() async {
    try {
      final XFile? file = await imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );
      if (file != null) {
        setState(() {
          selectedImage = file;
        });
        log(selectedImage!.path.toString());
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No image selected')),
        );
      }
    } catch (e) {
      log('Error picking image: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error picking image: $e')),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    getCred();
  }

  Future<String> uploadPost(XFile image) async {
    Reference storage = FirebaseStorage.instance.ref().child(
        "reports/post/${DateTime.now().millisecondsSinceEpoch}.jpg");
    UploadTask task = storage.putFile(File(image.path));
    TaskSnapshot snapshot = await task;
    return snapshot.ref.getDownloadURL();
  }

  Future<void> SubmitPost() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      String? imageUrl;
      setState(() {
        isLoading = true;
      });

      try {
        if (selectedImage != null) {
          imageUrl = await uploadPost(selectedImage!);
        }

        Map<String, dynamic> post = {
          "title": title,
          "image": imageUrl,
          "body": body,
          "email": userEmail,
        };

        if (userId != null) {
          await FirebaseFirestore.instance.collection('users').doc(userId).collection('posts').add(post);
          await FirebaseFirestore.instance.collection('posts').add(post);
        }

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Posted!')),
        );

        setState(() {
          title = null;
          body = null;
          selectedImage = null;
        });
        _formKey.currentState!.reset();
      } catch (e) {
        log('Failed to submit post: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to submit report: $e')),
        );
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Container(
              margin: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                  Center(
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            if (FocusScope.of(context).hasFocus) {
                              FocusScope.of(context).unfocus();
                              Future.delayed(const Duration(milliseconds: 500), () {
                                Navigator.pop(context);
                              });
                            } else {
                              Navigator.pop(context);
                            }
                          },
                          child: const Icon(Icons.arrow_back_ios_new_rounded,
                              size: 20, color: Colors.yellowAccent),
                        ),
                        Expanded(
                          child: Text(
                            "Forum",
                            textAlign: TextAlign.center,
                            style: CustomTextFormField.CustomText(
                              fontSize: 40,
                              fontFamily: "Bungee",
                              color: Colors.yellowAccent,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            CustomTextFormField.customTextFormField(
                              hintText: "Enter Title",
                              prefixIcon: Icons.title,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter a Title';
                                }
                                return null;
                              },
                              onSaved: (value) => title = value,
                            ),
                            SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                            Container(
                              padding: const EdgeInsets.all(10),
                              width: MediaQuery.of(context).size.width,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: Colors.yellowAccent,
                                  width: 4,
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Pick Image",
                                    style: CustomTextFormField.CustomText(
                                      fontSize: 30,
                                      color: Colors.white,
                                    ),
                                  ),
                                  SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                                  Center(
                                    child: GestureDetector(
                                      onTap: pickImage,
                                      child: Container(
                                        padding: const EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(20),
                                          border: Border.all(
                                            color: Colors.white,
                                            width: 2,
                                          ),
                                        ),
                                        margin: const EdgeInsets.all(10),
                                        width: 150,
                                        height: 150,
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(10),
                                          child: selectedImage == null
                                              ? Image.asset(
                                            "Assets/Images/galary.png",
                                            width: 100,
                                            height: 100,
                                            fit: BoxFit.cover,
                                          )
                                              : Image.file(
                                            File(selectedImage!.path),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                                  Center(
                                    child: Text(
                                      selectedImage != null
                                          ? path.basename(selectedImage!.path)
                                          : "No Image selected",
                                      style: CustomTextFormField.CustomText(
                                        fontSize: 20,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                                ],
                              ),
                            ),
                            SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                            CustomTextFormField.customTextFormField(
                              hintText: "Enter About Problem",
                              prefixIcon: Icons.description,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter a Description';
                                }
                                return null;
                              },
                              onSaved: (value) => body = value,
                            ),
                            SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                            SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton(
                                style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all<Color>(Colors.yellowAccent),
                                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      side: const BorderSide(color: Colors.yellowAccent, width: 2),
                                    ),
                                  ),
                                ),
                                onPressed: SubmitPost,
                                child: const Text(
                                  "Submit",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                            SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton(
                                style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all<Color>(Colors.yellowAccent),
                                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      side: const BorderSide(color: Colors.yellowAccent, width: 2),
                                    ),
                                  ),
                                ),
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (_) => ShowPost(email: email ?? '')));
                                },
                                child: const Text(
                                  "Show Post",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (isLoading)
              const Center(
                child: CircularProgressIndicator(
                  color: Colors.yellowAccent,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
