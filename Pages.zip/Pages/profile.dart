import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:uberclone/Local/SharedPreference.dart';
import 'package:uberclone/Widgets/CustomWidgets.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  String? email;
  String? name;
  String? address;
  String? mobileNo;
  String? emergencyNo;

  TextEditingController nameController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController mobileNoController = TextEditingController();
  TextEditingController emergencyNoController = TextEditingController();

  Future<void> getCred() async {
    String? email = await SharedpreferenceClass.getUserEmail();
    String? name = await SharedpreferenceClass.getUserName();
    setState(() {
      this.email = email;
      this.name = name;
      nameController.text = name ?? '';
    });
  }

  Future<void> getUserInfo() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection("users").doc(user.uid).get();
      log(userDoc.data().toString());
      setState(() {
        address = userDoc["address"] ?? "No address available";
        mobileNo = userDoc["mobileNo"] ?? "No mobile number available";
        emergencyNo = userDoc["emergencyNumber"] ?? "No emergency number available";

        addressController.text = address!;
        mobileNoController.text = mobileNo!;
        emergencyNoController.text = emergencyNo!;
      });
    }
  }
  Future<void> updateUserInfo() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      bool hasChanged = false;

      // Compare original values with current values in the text controllers
      if (nameController.text != name) {
        hasChanged = true;
        await FirebaseFirestore.instance.collection("users").doc(user.uid).update({
          "fullName": nameController.text,
        });
        await SharedpreferenceClass.setname(nameController.text);
      }

      if (addressController.text != address) {
        hasChanged = true;
        await FirebaseFirestore.instance.collection("users").doc(user.uid).update({
          "address": addressController.text,
        });
      }

      if (mobileNoController.text != mobileNo) {
        hasChanged = true;
        await FirebaseFirestore.instance.collection("users").doc(user.uid).update({
          "mobileNo": mobileNoController.text,
        });
      }

      if (emergencyNoController.text != emergencyNo) {
        hasChanged = true;
        await FirebaseFirestore.instance.collection("users").doc(user.uid).update({
          "emergencyNumber": emergencyNoController.text,
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(hasChanged ? "Profile updated successfully" : "No changes to update"),
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    getCred();
    getUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        width: MediaQuery.of(context).size.width,
        margin: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: MediaQuery.of(context).size.height*.02,),
            Center(
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      if(FocusScope.of(context).hasFocus) {
                        FocusScope.of(context).unfocus();
                        Future.delayed(const Duration(milliseconds: 300), () {
                          Navigator.pop(context);
                        });
                      }
                      else{
                        Navigator.pop(context);
                      }
                    },
                    child: Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: Colors.yellowAccent),
                  ),
                  Expanded(
                    child: Text(
                      "Profile",
                      textAlign: TextAlign.center,
                      style: CustomTextFormField.CustomText(
                        fontSize: 40,
                        fontFamily: "Bungee",
                        color: Colors.yellowAccent,
                      ),
                    ),),
                ],
              ),
            ),
            SizedBox(height: MediaQuery.of(context).size.height * 0.02),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Center(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(70),
                        child: Image.asset(
                          "Assets/Images/user.png",
                          width: 150,
                          height: 150,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.03),
                    Center(
                      child: Text(
                        this.email.toString(),
                        textAlign: TextAlign.center,
                        style: CustomTextFormField.CustomText(fontSize: 20, color: Colors.yellowAccent),
                      ),
                    ),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.03),
                    buildTextField("Name", nameController),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                    buildTextField("Address", addressController, maxLines: 2),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                    buildTextField("Phone no", mobileNoController),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                    buildTextField("Emergency Phone no", emergencyNoController),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(Colors.yellowAccent),
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              side: const BorderSide(color: Colors.yellowAccent, width: 4),
                            ),
                          ),
                        ),
                        onPressed: updateUserInfo,
                        child: const Text(
                          "Submit",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller, {int maxLines = 1}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: MediaQuery.of(context).size.width * 0.45,
          child: Text(
            label,
            style: CustomTextFormField.CustomText(fontSize: 20, color: Colors.yellowAccent),
          ),
        ),
        SizedBox(width: MediaQuery.of(context).size.width * 0.02),
        Expanded(
          child: TextFormField(
            controller: controller,
            maxLines: maxLines,
            style: TextStyle(color: Colors.white, fontSize: 20),
            decoration: InputDecoration(
              border: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.yellowAccent),
              ),
              enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.yellowAccent),
              ),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.yellowAccent),
              ),
              hintText: "Enter $label",
              hintStyle: TextStyle(color: Colors.grey),
            ),
          ),
        ),
      ],
    );

  }
}
