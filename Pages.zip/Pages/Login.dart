import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../Pages/Home.dart';
import '../Pages/Register.dart';
import '../Pages/ResetPass.dart';
import '../Local/SharedPreference.dart';
import '../Widgets/CustomWidgets.dart';
import 'package:http/http.dart' as http;

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();
  String? email;
  String? password;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;
  String? userName;
  String? usePass;
  Future<bool> _checkNetworkConnectivity() async {
    try {
      final response = await http.get(Uri.parse('https://www.google.com'));
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  Future<void> logIn() async {
    FocusScope.of(context).unfocus(); // Close the keyboard
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      setState(() {
        _isLoading = true;
      });

      try {

        if (!await _checkNetworkConnectivity()) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("No internet connection"),
              backgroundColor: Colors.red,
            ),
          );
          setState(() {
            _isLoading = false;
          });
          return;
        }

        DocumentSnapshot<Map<String, dynamic>> adminCred = await FirebaseFirestore.instance.collection('Admin').doc(email).get();
        bool admin = false;

        if (adminCred.exists) {
          String? adminUser = adminCred['username'];
          String? adminPass = adminCred['password'];
          String? adminid = adminCred.id;
          if (email == adminUser && adminPass == password) {
            admin = true;
          }
        }

        if (admin) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Logged in as Admin!")),
          );
          await SharedpreferenceClass.setUserId(adminCred.id);
          await SharedpreferenceClass.setEmail(email!);
          await SharedpreferenceClass.setPass(password!);
          await SharedpreferenceClass.setname("Admin");
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => Home(isAdmin: true,)),
                (Route<dynamic> route) => false,
          );
        } else {
          setState(() {
            this.usePass=password;
            this.userName=email;
          });

          UserCredential userCredential = await _auth.signInWithEmailAndPassword(
            email: email!,
            password: password!,
          );

          DocumentSnapshot userDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(userCredential.user!.uid)
              .get();

          String fullName = userDoc['fullName'];
          await SharedpreferenceClass.setUserId(userCredential.user!.uid);
          await SharedpreferenceClass.setEmail(userName.toString());
          await SharedpreferenceClass.setPass(usePass.toString());
          await SharedpreferenceClass.setname(fullName);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Logged in successfully!")),
          );

          // Navigate to Home and remove all previous activities
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => Home(isAdmin: false,)),
                (Route<dynamic> route) => false, // Removes all previous routes
          );
        }
      } on FirebaseAuthException catch (e) {
        String errorMessage = "Invalid Username or password";
        if (e.code == 'user-not-found' || e.code == 'wrong-password') {
          errorMessage = "Invalid email or password.";
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(errorMessage),
            backgroundColor: Colors.red,
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("An error occurred: $e"),
            backgroundColor: Colors.red,
          ),
        );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus(); // Close the keyboard if user taps outside
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.2),
                  Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: const [
                        Text(
                          "Welcome!",
                          style: TextStyle(
                            color: Colors.yellowAccent,
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                            fontFamily: "Bungee",
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          "Log in to continue",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: MediaQuery.of(context).size.height * 0.05),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            CustomTextFormField.customTextFormField(
                              hintText: "Email or username",
                              prefixIcon: Icons.email_outlined,
                              keyboardType: TextInputType.emailAddress,
                              validator: (value) {
                                if (value == null ||
                                    value.isEmpty ||
                                    !RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                                        .hasMatch(value)) {
                                  return 'Please enter a valid email address';
                                }
                                return null;
                              },
                              onSaved: (value) => email = value,
                            ),
                            const SizedBox(height: 20),
                            CustomTextFormField.customTextFormField(
                              hintText: "Password",
                              prefixIcon: Icons.lock_outline,
                              obscureText: true,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter a password';
                                } else if (value.length < 6) {
                                  return 'Password must be at least 6 characters long';
                                }
                                return null;
                              },
                              onSaved: (value) => password = value,
                            ),
                            const SizedBox(height: 20),
                            Align(
                              alignment: Alignment.centerRight,
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (_) => ForgotPass()));
                                },
                                child: const Text(
                                  "Forgot Password?",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton(
                                style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all<Color>(Colors.yellowAccent),
                                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      side: const BorderSide(color: Colors.yellowAccent, width: 2),
                                    ),
                                  ),
                                ),
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {
                                    logIn();
                                  }
                                },
                                child: const Text(
                                  "Log In",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text(
                                  "Don't have an account?",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                TextButton(
                                  onPressed: () {
                                    Navigator.push(context, MaterialPageRoute(builder: (_) => GetRegister()));
                                  },
                                  child: const Text(
                                    " Sign Up",
                                    style: TextStyle(
                                      color: Colors.yellowAccent,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (_isLoading)
              Container(
                color: Colors.black54,
                child: Center(
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.yellowAccent),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
