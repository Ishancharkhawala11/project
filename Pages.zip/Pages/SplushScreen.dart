import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uberclone/Local/SharedPreference.dart';
import 'package:uberclone/Pages/Home.dart';
import 'package:uberclone/Pages/Login.dart';

class Splashscreen extends StatefulWidget {
  const Splashscreen({super.key});

  @override
  State<Splashscreen> createState() => _SplashscreenState();
}

class _SplashscreenState extends State<Splashscreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () async {
      User? user = FirebaseAuth.instance.currentUser;

      if (user == null) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Login()));
      } else {
        // Check if the user is an admin
        DocumentSnapshot<Map<String, dynamic>> adminCred = await FirebaseFirestore.instance.collection('Admin').doc(user.email).get();

        if (adminCred.exists) {
          String? adminUser = adminCred['username'];
          String? adminPass = adminCred['password'];
          // Assuming you have saved user password in shared preferences or some secure storage
          String? password = await SharedpreferenceClass.getUserPass();

          if (adminUser != null && adminPass != null && password != null) {
            if (user.email == adminUser && password == adminPass) {
              // User is an admin
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => Home(isAdmin: true)));
            } else {
              // User is a regular user
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => Home(isAdmin: false)));
            }
          } else {
            // User is a regular user if admin credentials do not match
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => Home(isAdmin: false)));
          }
        } else {
          // User is a regular user if no admin credentials found
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => Home(isAdmin: false)));
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              "Assets/Images/fsos2.png",
              width: 200,
              height: 200,
            ),
            SizedBox(
              height: MediaQuery.of(context).size.width * .04,
            ),
            Text(
              "Jan Suvidha",
              style: TextStyle(
                  color: Colors.yellow.shade700,
                  fontSize: 50,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
